//
//  CTConstant.swift
//  CommonToolkit
//
//  Created by Abhishek Jaiswal on 05/03/19.
//  Copyright © 2019 TechtreeIt. All rights reserved.
//

public struct CTConstants {
    
    public enum DateFormat: String {
        
        case UTC = "yyyy-MM-dd'T'HH:mm:ss"
        case UTC12Hours = "yyyy-MM-dd'T'hh:mm:ss"
        case dateFormaterOne = "yyyy-MM-dd HH:mm:ss"
        case dateFormaterTwo = "yyyy-MM-dd"
        case dateFormaterThree = "HH:mm"
        case dateFormaterFour = "dd-MMM-yyyy"
        case dateFormaterFive = "MMM-yyyy"
        case dateFormaterSix = "yyyy"
        case dateFormaterSeven = "dd-MMM-yyyy HH:mm"
        case dateFormaterEight = "E dd-MMM-yyyy"
        case dateFormaterNine = "E, d MMM, HH:mm"
        case dateFormaterTen = "yyyy-MM-dd'T'HH:mm:ssxxxxx"
        case dateFormaterEleven = "yyyy-MM-dd'T'HH:mm:ss.SSSSxxxxx"
        case dateFormaterTwelve = "HH:mm:ss"
        case dateFormaterThirteen = "yyyy-MM-dd'T'HH:mm:ss.SSS"
        
    }
    
    public struct TimeInterval {
        
        public static let now = Foundation.TimeInterval(0)
        public static let demoDelay = Foundation.TimeInterval(2)
        public static let halfSecond = Foundation.TimeInterval(0.5)
        public static let second = Foundation.TimeInterval(1)
        public static let twoSeconds = Foundation.TimeInterval(2)
        public static let fiveSeconds = Foundation.TimeInterval(5)
        public static let tenSeconds = Foundation.TimeInterval(10)
        public static let twentySeconds = Foundation.TimeInterval(20)
        public static let thirtySeconds = Foundation.TimeInterval(30)
        public static let minute = Foundation.TimeInterval(60)
        public static let tenMinutes = Foundation.TimeInterval(60 * 10)
        public static let quarterHour = Foundation.TimeInterval(60 * 15)
        public static let halfHour = Foundation.TimeInterval(60 * 30)
        public static let hour = Foundation.TimeInterval(60 * 60)
        public static let eightHours = Foundation.TimeInterval(60 * 60 * 8)
        public static let day = Foundation.TimeInterval(60 * 60 * 24)
        public static let week = Foundation.TimeInterval(60 * 60 * 24 * 7)
        public static let ninetyDays = Foundation.TimeInterval(60 * 60 * 24 * 90)
        
    }
    
    public struct Animation {
        
        public static let short: CFTimeInterval = 0.125
        public static let medium: CFTimeInterval = 0.25
        public static let long: CFTimeInterval = 0.5
        public static let longer: CFTimeInterval = 1
        public static let longest: CFTimeInterval = 2
        public static let springDamping: CGFloat = 0.6
        public static let springVelocity: CGFloat = 0
        
    }
    
    public static let navigationStackViewControllersIndex = 2
    
}
