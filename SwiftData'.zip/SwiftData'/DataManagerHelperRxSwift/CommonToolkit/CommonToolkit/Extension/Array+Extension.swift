//
//  Array+Extension.swift
//  CommonToolkit
//
//  Created by Abhishek Jaiswal on 05/03/19.
//  Copyright © 2019 TechtreeIt. All rights reserved.
//

public extension Array where Element: Operation {
    
    func allOperationFinish(block: @escaping () -> Void) {
        
        let doneOperation = BlockOperation(block: block)
        self.forEach { [unowned doneOperation] in doneOperation.addDependency($0) }
        OperationQueue().addOperation(doneOperation)
        
    }
    
    func cancelUnfinishedOperations() {
        
        for operation in self {
            
            if !operation.isFinished {
                operation.cancel()
            }
            
        }
        
    }
    
}
