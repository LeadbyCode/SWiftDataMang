//
//  Calendar+Extension.swift
//  CommonToolkit
//
//  Created by Abhishek Jaiswal on 05/03/19.
//  Copyright © 2019 TechtreeIt. All rights reserved.
//

import Foundation

public extension Calendar {
    
    public static func defaultCalendar() -> Calendar {
        
        var calendar = Calendar(identifier: Calendar.Identifier.gregorian)
        calendar.timeZone = TimeZone(identifier: "UTC")!
        
        //Mark : 2 = Monday
        calendar.firstWeekday = 2
        
        return calendar
        
    }
    
}
