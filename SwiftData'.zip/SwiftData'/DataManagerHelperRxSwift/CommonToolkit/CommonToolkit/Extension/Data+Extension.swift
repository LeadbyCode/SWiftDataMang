//
//  Data+Extension.swift
//  CommonToolkit
//
//  Created by Abhishek Jaiswal on 05/03/19.
//  Copyright © 2019 TechtreeIt. All rights reserved.
//

public extension Data {
    
    public func toString(_ encoding: String.Encoding = String.Encoding.utf8) -> String? {
        
        return String(data: self, encoding: encoding)
        
    }
    
    public func toBase64String(_ options: NSData.Base64EncodingOptions = []) -> String? {
        
        return self.base64EncodedString(options: [])
        
    }
    
    public func toBase64Data(_ options: NSData.Base64EncodingOptions = []) -> Data? {
        
        return self.base64EncodedData(options: [])
        
    }
    
}
