//
//  Date+Extension.swift
//  CommonToolkit
//
//  Created by Abhishek Jaiswal on 05/03/19.
//  Copyright © 2019 TechtreeIt. All rights reserved.
//

public extension Date {
    
    public var localDate: Date {
        
        if NSTimeZone.local.isDaylightSavingTime() {
            let offset = Int(NSTimeZone.local.daylightSavingTimeOffset())
            return (Calendar.current as NSCalendar).date(byAdding: .second, value: offset, to: self, options: NSCalendar.Options(rawValue: 0))!
        }
        
        return self
        
    }
    
    public var localDateWithoutDST: Date {
        
        if NSTimeZone.local.isDaylightSavingTime() {
            let offset = Int(NSTimeZone.local.daylightSavingTimeOffset())
            return (Calendar.current as NSCalendar).date(byAdding: .second, value: -offset, to: self, options: NSCalendar.Options(rawValue: 0))!
        }
        
        return self
        
    }
    
    public var localTimeIntervalSinceNow: TimeInterval {
        
        if NSTimeZone.local.isDaylightSavingTime() {
            let offset = NSTimeZone.local.daylightSavingTimeOffset()
            return timeIntervalSinceNow - offset
        }
        
        return timeIntervalSinceNow
        
    }
    
    public func dateNoTime() -> Date {
        
        let components = (Calendar.defaultCalendar() as NSCalendar).components([.year, .month, .day], from: self)
        
        let date = Calendar.defaultCalendar().date(from: components)!
        
        return date
        
    }
    
    public func timeNoDate() -> Date {
        
        let components = (Calendar.defaultCalendar() as NSCalendar).components([.hour, .minute, .second], from: self)
        let date = Calendar.defaultCalendar().date(from: components)!
        
        return date
        
    }
    
    public func stringWithDateFormat(_ format: CTConstants.DateFormat) -> String {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format.rawValue
        return dateFormatter.string(from: self)
        
    }
    
    public func getSeconds(from: Date) -> Int {
        
        return Calendar.defaultCalendar().dateComponents([.second], from: from, to: self).second ?? 0
        
    }
    
    public func dateByAddingYears(_ addYears: Int) -> Date? {
        
        var components = DateComponents()
        components.year = addYears
        let calendar = Calendar.defaultCalendar()
        let newDate = (calendar as NSCalendar).date(byAdding: components, to: self, options: NSCalendar.Options(rawValue: 0))
        
        return newDate
        
    }
    
    public func dateByAddingMonths(_ addMonths: Int) -> Date? {
        
        var components = DateComponents()
        components.month = addMonths
        let calendar = Calendar.defaultCalendar()
        let newDate = (calendar as NSCalendar).date(byAdding: components, to: self, options: NSCalendar.Options(rawValue: 0))
        
        return newDate
        
    }
    
    public func dateByAddingWeeks(_ addWeeks: Int) -> Date? {
        
        var components = DateComponents()
        components.day = addWeeks * 7
        let calendar = Calendar.defaultCalendar()
        let newDate = (calendar as NSCalendar).date(byAdding: components, to: self, options: NSCalendar.Options(rawValue: 0))
        
        return newDate
        
    }
    
    public func dateByAddingDays(_ addDays: Int) -> Date? {
        
        var components = DateComponents()
        components.day = addDays
        let calendar = Calendar.defaultCalendar()
        let newDate = (calendar as NSCalendar).date(byAdding: components, to: self, options: NSCalendar.Options(rawValue: 0))
        
        return newDate
        
    }
    
    public func dateByAddingHours(_ addHours: Int) -> Date? {
        
        let timeInterval = TimeInterval(addHours * 60 * 60)
        return self.addingTimeInterval(timeInterval)
        
    }
    
    public func dateByAddingSeconds(_ addSeconds: Int) -> Date? {
        
        let timeInterval = TimeInterval(addSeconds)
        return self.addingTimeInterval(timeInterval)
        
    }
    
    public init?(iso8601String: String) {
        
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale.current
        dateFormatter.timeZone = TimeZone(secondsFromGMT: 0)
        
        dateFormatter.dateFormat = CTConstants.DateFormat.UTC.rawValue
        
        if let date = dateFormatter.date(from: iso8601String) {
            self = date.localDate
        } else {
            
            dateFormatter.dateFormat = CTConstants.DateFormat.UTC12Hours.rawValue
            
            if let date = dateFormatter.date(from: iso8601String) {
                self = date.localDate
            } else {
                return nil
            }
            
        }
        
    }
    
    public func isLeapYear() -> Bool {
        
        var component = Calendar.defaultCalendar().dateComponents([.day, .month, .year, .weekday], from: self)
        
        let year = component.year!
        
        return ((year % 4) == 0) && (((year % 100) != 0) || ((year % 400) == 0))
        
    }
    
    public func dateWithReferenceDayOfMonth(dayOfMonth: Int) -> Date? {
        
        var day = dayOfMonth
        var component = Calendar.defaultCalendar().dateComponents([.day, .month, .year, .weekday], from: self)
        
        let month = component.month!
        
        if dayOfMonth > 28 && month == 2 {
            day = self.isLeapYear() ? 29 : 28
        } else if dayOfMonth == 31 {
            
            switch month {
            case 4, 6, 9, 11:
                day = 30
                
            default:
                day = 31
            }
            
        }
        
        component.setValue(day, for: .day)
        
        return Calendar.defaultCalendar().date(from: component)
        
    }
    
    public func isWeekDay() -> Bool {
        
        let calendar = Calendar.defaultCalendar()
        let component = calendar.dateComponents([.weekday], from: self) as NSDateComponents
        
        return ((component.weekday >= 2) && (component.weekday <= 6))
        
    }
    
    func isDateWithGivenDay(referenceDay: Int) -> Bool {
        
        let calendar = Calendar.defaultCalendar()
        let component = calendar.dateComponents([.weekday], from: self) as NSDateComponents
        
        return component.weekday == referenceDay
        
    }
    
}
