//
//  NSFileManager+Extension.swift
//  CommonToolkit
//
//  Created by Abhishek Jaiswal on 05/03/19.
//  Copyright © 2019 TechtreeIt. All rights reserved.
//

public extension FileManager {
    
    public static func initialiseFolder(_ folderName: String, clearFolder: Bool) {
        
        guard let confirmedDocumentsDirectoryPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first else {
            return
        }
        
        let folderPath = confirmedDocumentsDirectoryPath.appending(folderName)
        
        if FileManager.default.fileExists(atPath: folderPath) {
            
            if clearFolder {
                FileManager.deleteFolderWithName(folderName, path: folderPath)
                FileManager.addFolderWithName(folderName, path: folderPath)
            }
            
        } else {
            
            FileManager.addFolderWithName(folderName, path: folderPath)
            
        }
        
    }
    
    static func deleteFolderWithName(_ folderName: String, path folderPath: String) {
        
        do {
            try FileManager.default.removeItem(atPath: folderPath)
            print("Folder removed")
        } catch {
            print("Could not remove folder")
        }
        
    }
    
    static func addFolderWithName(_ folderName: String, path folderPath: String) {
        
        do {
            try FileManager.default.createDirectory(atPath: folderPath, withIntermediateDirectories: false, attributes: nil)
            print("Folder Created")
        } catch {
            print("Could not create folder")
        }
        
    }
    
}
