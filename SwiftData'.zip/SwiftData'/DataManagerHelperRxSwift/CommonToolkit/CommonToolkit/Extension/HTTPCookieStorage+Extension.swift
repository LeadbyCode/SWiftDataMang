//
//  HTTPCookieStorage+Extension.swift
//  CommonToolkit
//
//  Created by Abhishek Jaiswal on 05/03/19.
//  Copyright © 2019 TechtreeIt. All rights reserved.
//

public extension HTTPCookieStorage {
    
    public func deleteAllCookies() {
        
        guard let confirmedCookies = self.cookies else {
            return
        }
        
        for cookie in confirmedCookies {
            self.deleteCookie(cookie)
        }
        
        UserDefaults.standard.synchronize()
        
    }
    
}
