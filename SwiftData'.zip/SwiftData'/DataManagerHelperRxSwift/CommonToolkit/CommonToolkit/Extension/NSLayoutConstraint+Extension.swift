//
//  NSLayoutConstraint+Extension.swift
//  CommonToolkit
//
//  Created by Abhishek Jaiswal on 05/03/19.
//  Copyright © 2019 TechtreeIt. All rights reserved.
//

public extension NSLayoutConstraint {
    
    public class func constraintsWithViews(_ views: [String: Any], metrics: [String: Any]?, options: NSLayoutConstraint.FormatOptions = NSLayoutConstraint.FormatOptions(rawValue: 0),
                                           visualFormats: String...) -> [NSLayoutConstraint] {
        
        var combinedConstraints = [NSLayoutConstraint]()
        
        for visualFormat in visualFormats {
            
            let constraints = NSLayoutConstraint.constraints(withVisualFormat: visualFormat, options: options, metrics: metrics, views: views)
            
            combinedConstraints.append(contentsOf: constraints)
            
        }
        
        return combinedConstraints
        
    }
    
    public class func combinedConstraintsWithViews(_ views: [String: Any], metrics: [String: Any]?, options: NSLayoutConstraint.FormatOptions = NSLayoutConstraint.FormatOptions(rawValue: 0),
                                                   visualFormats: [String]) -> [NSLayoutConstraint] {
        
        var combinedConstraints = [NSLayoutConstraint]()
        
        for visualFormat in visualFormats {
            
            let constraints = NSLayoutConstraint.constraints(withVisualFormat: visualFormat, options: options, metrics: metrics, views: views)
            
            combinedConstraints.append(contentsOf: constraints)
            
        }
        
        return combinedConstraints
        
    }
    
    static func constrainSize(_ view: UIView, size: CGSize) -> [NSLayoutConstraint] {
        
        let constraintWidth = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil,
                                                 attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1.0, constant: size.width)
        let constraintHeight = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil,
                                                  attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1.0, constant: size.height)
        
        return [constraintWidth, constraintHeight]
        
    }
    
    static func constrainWidth(_ view: UIView, width: CGFloat) -> NSLayoutConstraint {
        
        let constraint = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil,
                                            attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1.0, constant: width)
        
        return constraint
        
    }
    
    static func constrainHeight(_ view: UIView, height: CGFloat) -> NSLayoutConstraint {
        
        let constraint = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil,
                                            attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1.0, constant: height)
        
        return constraint
        
    }
    
    static func constrainWidthRelative(_ view: UIView, relatedView: Any?, multiplier: CGFloat = 1.0, offset: CGFloat = 0, relation: NSLayoutConstraint.Relation = .equal) -> NSLayoutConstraint {
        
        let constraint = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.width, relatedBy: relation, toItem: relatedView,
                                            attribute: NSLayoutConstraint.Attribute.width, multiplier: multiplier, constant: offset)
        
        return constraint
        
    }
    
    static func constrainHeightRelative(_ view: UIView, relatedView: Any?, multiplier: CGFloat = 1.0, offset: CGFloat = 0) -> NSLayoutConstraint {
        
        let constraint = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: relatedView,
                                            attribute: NSLayoutConstraint.Attribute.height, multiplier: multiplier, constant: offset)
        
        return constraint
        
    }
    
    static func center(_ view: UIView, relatedView: Any?) -> [NSLayoutConstraint] {
        
        let centerX = NSLayoutConstraint.centerX(view, relatedView: relatedView)
        let centerY = NSLayoutConstraint.centerY(view, relatedView: relatedView)
        
        return [centerX, centerY]
        
    }
    
    static func centerX(_ view: UIView, relatedView: Any?, offset: CGFloat = 0) -> NSLayoutConstraint {
        
        let constraint = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: relatedView,
                                            attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1.0, constant: offset)
        
        return constraint
        
    }
    
    static func centerY(_ view: UIView, relatedView: Any?, offset: CGFloat = 0) -> NSLayoutConstraint {
        
        let constraint = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.centerY, relatedBy: NSLayoutConstraint.Relation.equal, toItem: relatedView,
                                            attribute: NSLayoutConstraint.Attribute.centerY, multiplier: 1.0, constant: offset)
        
        return constraint
        
    }
    
    // swiftlint:disable line_length
    static func pinAttribute(_ attibute: NSLayoutConstraint.Attribute, view: UIView, relatedAttribute: NSLayoutConstraint.Attribute, relatedView: Any?, constant: CGFloat) -> NSLayoutConstraint {
        
        let constraint = NSLayoutConstraint(item: view, attribute: attibute, relatedBy: NSLayoutConstraint.Relation.equal, toItem: relatedView, attribute: relatedAttribute, multiplier: 1.0, constant: constant)
        
        return constraint
        
    }
    
    static func pinLeftToCenterX(_ view: UIView, relatedView: Any?, offset: CGFloat = 0) -> NSLayoutConstraint {
        
        let constraint = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.left, relatedBy: NSLayoutConstraint.Relation.equal, toItem: relatedView,
                                            attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1.0, constant: offset)
        
        return constraint
        
    }
    
    static func pinRightToCenterX(_ view: UIView, relatedView: Any?, offset: CGFloat = 0) -> NSLayoutConstraint {
        
        let constraint = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.right, relatedBy: NSLayoutConstraint.Relation.equal, toItem: relatedView,
                                            attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1.0, constant: offset)
        
        return constraint
        
    }
    
    static func pinTopToCenterY(_ view: UIView, relatedView: Any?, offset: CGFloat = 0) -> NSLayoutConstraint {
        
        let constraint = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: relatedView,
                                            attribute: NSLayoutConstraint.Attribute.centerY, multiplier: 1.0, constant: offset)
        
        return constraint
        
    }
    
    static func pinBottomToCenterY(_ view: UIView, relatedView: Any?, offset: CGFloat = 0) -> NSLayoutConstraint {
        
        let constraint = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.bottom, relatedBy: NSLayoutConstraint.Relation.equal, toItem: relatedView,
                                            attribute: NSLayoutConstraint.Attribute.centerY, multiplier: 1.0, constant: offset)
        
        return constraint
        
    }
    
    static func pinLeft(_ view: UIView, relatedView: Any?, offset: CGFloat = 0) -> NSLayoutConstraint {
        
        let constraint = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.left, relatedBy: NSLayoutConstraint.Relation.equal, toItem: relatedView,
                                            attribute: NSLayoutConstraint.Attribute.right, multiplier: 1.0, constant: offset)
        
        return constraint
        
    }
    
    static func pinRight(_ view: UIView, relatedView: Any?, offset: CGFloat = 0) -> NSLayoutConstraint {
        
        let constraint = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.right, relatedBy: NSLayoutConstraint.Relation.equal, toItem: relatedView,
                                            attribute: NSLayoutConstraint.Attribute.left, multiplier: 1.0, constant: offset * -1.0)
        
        return constraint
        
    }
    
    static func pinTop(_ view: UIView, relatedView: Any?, offset: CGFloat = 0) -> NSLayoutConstraint {
        
        let constraint = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: relatedView,
                                            attribute: NSLayoutConstraint.Attribute.bottom, multiplier: 1.0, constant: offset)
        
        return constraint
        
    }
    
    static func pinBottom(_ view: UIView, relatedView: Any?, offset: CGFloat = 0) -> NSLayoutConstraint {
        
        let constraint = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.bottom, relatedBy: NSLayoutConstraint.Relation.equal, toItem: relatedView,
                                            attribute: NSLayoutConstraint.Attribute.top, multiplier: 1.0, constant: offset * -1.0)
        
        return constraint
        
    }
    
    static func alignTop(_ view: UIView, relatedView: Any?, offset: CGFloat = 0) -> NSLayoutConstraint {
        
        let constraint = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: relatedView,
                                            attribute: NSLayoutConstraint.Attribute.top, multiplier: 1.0, constant: offset)
        
        return constraint
        
    }
    
    static func alignBottom(_ view: UIView, relatedView: Any?, offset: CGFloat = 0) -> NSLayoutConstraint {
        
        let constraint = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.bottom, relatedBy: NSLayoutConstraint.Relation.equal, toItem: relatedView,
                                            attribute: NSLayoutConstraint.Attribute.bottom, multiplier: 1.0, constant: offset)
        
        return constraint
        
    }
    
    static func alignLeft(_ view: UIView, relatedView: Any?, offset: CGFloat = 0) -> NSLayoutConstraint {
        
        let constraint = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.left, relatedBy: NSLayoutConstraint.Relation.equal, toItem: relatedView,
                                            attribute: NSLayoutConstraint.Attribute.left, multiplier: 1.0, constant: offset)
        
        return constraint
        
    }
    
    static func alignRight(_ view: UIView, relatedView: Any?, offset: CGFloat = 0) -> NSLayoutConstraint {
        
        let constraint = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.right, relatedBy: NSLayoutConstraint.Relation.equal, toItem: relatedView,
                                            attribute: NSLayoutConstraint.Attribute.right, multiplier: 1.0, constant: offset)
        
        return constraint
        
    }
    
    static func fillX(_ view: UIView, relatedView: Any?, inset: CGFloat = 0) -> [NSLayoutConstraint] {
        
        let constraint1 = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.leading, relatedBy: NSLayoutConstraint.Relation.equal, toItem: relatedView,
                                             attribute: NSLayoutConstraint.Attribute.leading, multiplier: 1.0, constant: inset)
        
        let constraint2 = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.trailing, relatedBy: NSLayoutConstraint.Relation.equal, toItem: relatedView,
                                             attribute: NSLayoutConstraint.Attribute.trailing, multiplier: 1.0, constant: -inset)
        
        return [constraint1, constraint2]
        
    }
    
    static func fillY(_ view: UIView, relatedView: Any?, inset: CGFloat = 0) -> [NSLayoutConstraint] {
        
        let constraint1 = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: relatedView,
                                             attribute: NSLayoutConstraint.Attribute.top, multiplier: 1.0, constant: inset)
        
        let constraint2 = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.bottom, relatedBy: NSLayoutConstraint.Relation.equal, toItem: relatedView,
                                             attribute: NSLayoutConstraint.Attribute.bottom, multiplier: 1.0, constant: -inset)
        
        return [constraint1, constraint2]
        
    }
    
    static func fill(_ view: UIView, relatedView: Any?, inset: CGFloat = 0) -> [NSLayoutConstraint] {
        
        let topConstraint = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: relatedView,
                                               attribute: NSLayoutConstraint.Attribute.top, multiplier: 1.0, constant: inset)
        
        let leadingConstraint = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.leading, relatedBy: NSLayoutConstraint.Relation.equal, toItem: relatedView,
                                                   attribute: NSLayoutConstraint.Attribute.leading, multiplier: 1.0, constant: inset)
        
        let bottomConstraint = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.bottom, relatedBy: NSLayoutConstraint.Relation.equal, toItem: relatedView,
                                                  attribute: NSLayoutConstraint.Attribute.bottom, multiplier: 1.0, constant: -inset)
        
        let trailingContraint = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.trailing, relatedBy: NSLayoutConstraint.Relation.equal, toItem: relatedView,
                                                   attribute: NSLayoutConstraint.Attribute.trailing, multiplier: 1.0, constant: -inset)
        
        return [topConstraint, leadingConstraint, bottomConstraint, trailingContraint]
        
    }
    
    static func fill(_ view: UIView, relatedView: Any?, layoutMargins: UIEdgeInsets) -> [NSLayoutConstraint] {
        
        let topConstraint = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: relatedView,
                                               attribute: NSLayoutConstraint.Attribute.top, multiplier: 1.0, constant: layoutMargins.top)
        
        let leadingConstraint = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.leading, relatedBy: NSLayoutConstraint.Relation.equal, toItem: relatedView,
                                                   attribute: NSLayoutConstraint.Attribute.leading, multiplier: 1.0, constant: layoutMargins.left)
        
        let bottomConstraint = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.bottom, relatedBy: NSLayoutConstraint.Relation.equal, toItem: relatedView,
                                                  attribute: NSLayoutConstraint.Attribute.bottom, multiplier: 1.0, constant: -layoutMargins.bottom)
        
        let trailingContraint = NSLayoutConstraint(item: view, attribute: NSLayoutConstraint.Attribute.trailing, relatedBy: NSLayoutConstraint.Relation.equal, toItem: relatedView,
                                                   attribute: NSLayoutConstraint.Attribute.trailing, multiplier: 1.0, constant: -layoutMargins.right)
        
        return [topConstraint, leadingConstraint, bottomConstraint, trailingContraint]
        
    }
    
}
