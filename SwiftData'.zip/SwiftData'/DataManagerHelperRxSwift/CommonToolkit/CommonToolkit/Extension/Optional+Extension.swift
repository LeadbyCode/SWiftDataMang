//
//  Optional+Extension.swift
//  CommonToolkit
//
//  Created by Abhishek Jaiswal on 05/03/19.
//  Copyright © 2019 TechtreeIt. All rights reserved.
//

public extension Optional {
    
    func unwrap(_ errorExpression: @autoclosure () -> Error) throws -> Wrapped {
        
        guard let value = self else {
            throw errorExpression()
        }
        
        return value
        
    }
    
    func matching(_ predicate: (Wrapped) -> Bool) -> Wrapped? {
        
        guard let value = self else {
            return nil
        }
        
        guard predicate(value) else {
            return nil
        }
        
        return value
        
    }
    
}

extension Optional where Wrapped: Collection {
    
    var isNilOrEmpty: Bool {
        return self?.isEmpty ?? true
    }
    
}
