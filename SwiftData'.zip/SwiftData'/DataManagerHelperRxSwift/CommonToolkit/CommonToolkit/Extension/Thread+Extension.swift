//
//  Thread+Extension.swift
//  CommonToolkit
//
//  Created by Abhishek Jaiswal on 05/03/19.
//  Copyright © 2019 TechtreeIt. All rights reserved.
//

public extension Thread {
    
    public static func isBackgroundThread() -> Bool {
        
        return !Thread.isMainThread
        
    }
    
}
