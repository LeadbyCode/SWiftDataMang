//
//  UIImage+Extension.swift
//  CommonToolkit
//
//  Created by Abhishek Jaiswal on 05/03/19.
//  Copyright © 2019 TechtreeIt. All rights reserved.
//

public extension UIImage {
    
    public func resizeToScale(_ scale: CGFloat) -> UIImage {
        
        if scale == 1.0 {
            return self
        }
        
        guard let confirmedContext = UIGraphicsGetCurrentContext() else {
            return self
        }
        
        let imageView = UIImageView(frame: CGRect(origin: CGPoint(x: 0, y: 0), size: CGSize(width: size.width * scale, height: size.height * scale)))
        imageView.contentMode = UIView.ContentMode.scaleAspectFit
        imageView.image = self
        
        UIGraphicsBeginImageContext(imageView.bounds.size)
        
        imageView.layer.render(in: confirmedContext)
        let result = UIGraphicsGetImageFromCurrentImageContext()
        
        UIGraphicsEndImageContext()
        
        guard let confirmedResult = result else {
            return self
        }
        
        return confirmedResult
        
    }
    
    public func resizeToSize(_ size: CGSize) -> UIImage {
        
        UIGraphicsBeginImageContextWithOptions(size, false, 0.0)
        
        self.draw(in: CGRect(x: 0, y: 0, width: size.width, height: size.height))
        let result = UIGraphicsGetImageFromCurrentImageContext()
        
        UIGraphicsEndImageContext()
        
        guard let confirmedResult = result else {
            return self
        }
        
        return confirmedResult
        
    }
    
    public func resizeToWidth(_ width: CGFloat) -> UIImage {
        
        guard let confirmedContext = UIGraphicsGetCurrentContext() else {
            return self
        }
        
        let imageView = UIImageView(frame: CGRect(origin: CGPoint(x: 0, y: 0), size: CGSize(width: width, height: CGFloat(ceil(width/size.width * size.height)))))
        imageView.contentMode = UIView.ContentMode.scaleAspectFit
        imageView.image = self
        
        UIGraphicsBeginImageContext(imageView.bounds.size)
        
        imageView.layer.render(in: confirmedContext)
        let result = UIGraphicsGetImageFromCurrentImageContext()
        
        UIGraphicsEndImageContext()
        
        guard let confirmedResult = result else {
            return self
        }
        
        return confirmedResult
        
    }
    
    public func imageWithColour(_ colour: UIColor) -> UIImage {
                
        guard let confirmedContext = UIGraphicsGetCurrentContext() else {
            return self
        }
        
        UIGraphicsBeginImageContextWithOptions(self.size, false, self.scale)
        
        colour.setFill()
        confirmedContext.translateBy(x: 0, y: self.size.height)
        confirmedContext.scaleBy(x: 1.0, y: -1.0)
        
        confirmedContext.setBlendMode(CGBlendMode.normal)
        let rect = CGRect(x: 0, y: 0, width: self.size.width, height: self.size.height) as CGRect
        confirmedContext.clip(to: rect, mask: self.cgImage!)
        confirmedContext.fill(rect)
        
        let result = UIGraphicsGetImageFromCurrentImageContext()
        
        UIGraphicsEndImageContext()
        
        guard let confirmedResult = result else {
            return self
        }
        
        return confirmedResult
        
    }
    
}
