//
//  UILabel+Extension.swift
//  CommonToolkit
//
//  Created by Abhishek Jaiswal on 05/03/19.
//  Copyright © 2019 TechtreeIt. All rights reserved.
//

public extension UILabel {
    
    func setFontForLabel(maxFontSize: CGFloat, minFontSize: CGFloat, maxLines: Int) {
        var numLines: Int = 1
        var textSize: CGSize = CGSize.zero
        var frameSize: CGSize = CGSize.zero
        let font: UIFont = UIFont.systemFont(ofSize: maxFontSize)
        
        frameSize = self.frame.size
        
        textSize = (self.text! as NSString).size(withAttributes: [NSAttributedString.Key.font: font])
        
        while ((textSize.width/CGFloat(numLines)) / (textSize.height * CGFloat(numLines)) > frameSize.width / frameSize.height) && numLines < maxLines {
            numLines += 1
        }
        
        self.font = font
        self.adjustsFontSizeToFitWidth = true
        self.numberOfLines = numLines
        self.minimumScaleFactor = minFontSize/maxFontSize
    }
}
