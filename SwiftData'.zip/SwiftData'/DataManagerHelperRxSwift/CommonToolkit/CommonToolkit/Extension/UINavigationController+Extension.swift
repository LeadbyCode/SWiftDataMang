//
//  UINavigationController+Extension.swift
//  CommonToolkit
//
//  Created by Abhishek Jaiswal on 05/03/19.
//  Copyright © 2019 TechtreeIt. All rights reserved.
//

public extension UINavigationController {
    
    public func flashNavigationBar(count: Int, colour: UIColor, timeInterval: TimeInterval = CTConstants.TimeInterval.second) {
        
        let tmpColour = navigationBar.barTintColor
        let tmpTranslucent = navigationBar.isTranslucent
        
        navigationBar.isTranslucent = false
        
        UIView.animate(withDuration: timeInterval / 2.0, animations: { () -> Void in
            
            self.navigationBar.barTintColor = colour
            
        }, completion: { _ in
            
            UIView.animate(withDuration: timeInterval / 2.0, animations: { () -> Void in
                
                self.navigationBar.barTintColor = tmpColour
                self.navigationBar.isTranslucent = tmpTranslucent
                
            }, completion: { _ in
                
                if count > 1 {
                    self.flashNavigationBar(count: count - 1, colour: colour, timeInterval: timeInterval)
                }
                
            })
            
        })
        
    }
    
    public func flipViewController(_ controller: UIViewController, completion: ((Bool) -> Void)? = nil) {
        
        UIView.animate(withDuration: CTConstants.Animation.long, animations: {
            
            UIView.setAnimationCurve(UIView.AnimationCurve.easeInOut)
            self.pushViewController(controller, animated: false)
            UIView.setAnimationTransition(UIView.AnimationTransition.flipFromRight, for: self.view, cache: false)
            
        }, completion: completion)
        
    }
    
    public func flopViewController(_ completion: ((Bool) -> Void)? = nil) {
                
        UIView.animate(withDuration: CTConstants.Animation.long, animations: {
            
            UIView.setAnimationCurve(UIView.AnimationCurve.easeInOut)
            self.popViewController(animated: true)
            UIView.setAnimationTransition(UIView.AnimationTransition.flipFromLeft, for: self.view, cache: false)
            
        }, completion: completion)
        
    }
    
    public func isRootViewController(_ controller: UIViewController) -> Bool {
        
        if let confirmedViewController = viewControllers.first, confirmedViewController == controller {
            return true
        }
        
        return false
        
    }
    
    public func popViewController(animated: Bool, completion: @escaping () -> Void) {
        
        popViewController(animated: animated)
        
        if let coordinator = transitionCoordinator, animated {
            coordinator.animate(alongsideTransition: nil) { _ in
                completion()
            }
        } else {
            completion()
        }
        
    }
    
    public func lastControllerInNavigationStack() -> UIViewController {
        return self.viewControllers[self.viewControllers.count - CTConstants.navigationStackViewControllersIndex]
    }
    
    public func getViewControllerFromNavigationStack(controller: AnyClass) -> UIViewController {
        
        var stackViewController: UIViewController = UIViewController()
        
        for viewController in viewControllers {
            
            if viewController.isKind(of: controller) {
                stackViewController = viewController
            }
            
        }
        
        return stackViewController
        
    }
    
}
