//
//  UISearchBar+Extension.swift
//  CommonToolkit
//
//  Created by Abhishek Jaiswal on 05/03/19.
//  Copyright © 2019 TechtreeIt. All rights reserved.
//

public extension UISearchBar {
    
    func hasSearchText() -> Bool {
        
        if let confirmedSearchString = self.text?.trimmingCharacters(in: CharacterSet.whitespaces), !confirmedSearchString.isEmpty {
            
            return true
        }
        
        return false
    }
    
}
