//
//  UITextField+Extension.swift
//  CommonToolkit
//
//  Created by Abhishek Jaiswal on 05/03/19.
//  Copyright © 2019 TechtreeIt. All rights reserved.
//

public extension UITextField {
    
    public func configureForNumericInput() {
        
        clearButtonMode = .whileEditing
        keyboardType = .numbersAndPunctuation
        returnKeyType = .done
        autocapitalizationType = .none
        autocorrectionType = .no
        enablesReturnKeyAutomatically = true
        
    }
    
    public func configureForDefaultInput() {
        
        clearButtonMode = .whileEditing
        keyboardType = .default
        returnKeyType = .done
        autocapitalizationType = .sentences
        autocorrectionType = .no
        spellCheckingType = .no
        enablesReturnKeyAutomatically = true
        
    }
    
    public func configureForLoginInput() {
        
        clearButtonMode = .whileEditing
        keyboardType = .default
        returnKeyType = .done
        autocapitalizationType = .none
        autocorrectionType = .no
        spellCheckingType = .no
        enablesReturnKeyAutomatically = true
        
    }
    
    public func cleanText() -> String? {
        
        guard let confirmedText = self.text else {
            return nil
        }
        
        return confirmedText.trimmingCharacters(in: CharacterSet.whitespaces)
        
    }
        
}
