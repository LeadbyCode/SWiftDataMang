//
//  UITextView+Extension.swift
//  CommonToolkit
//
//  Created by Abhishek Jaiswal on 05/03/19.
//  Copyright © 2019 TechtreeIt. All rights reserved.
//

public extension UITextView {
    
    public func cleanText() -> String? {
        
        guard let confirmedText = self.text else {
            return nil
        }
        
        return confirmedText.trimmingCharacters(in: CharacterSet.whitespaces)
        
    }
    
    public func configureForDefaultInput() {
                
        keyboardType = .default
        returnKeyType = .default
        autocapitalizationType = .sentences
        autocorrectionType = .no
        spellCheckingType = .no
        
    }
    
}
