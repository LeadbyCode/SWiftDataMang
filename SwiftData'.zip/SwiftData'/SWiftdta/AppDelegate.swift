//
//  AppDelegate.swift
//  SWiftdta
//
//  Created by Nilesh Vernekar on 03/02/21.
//  Copyright © 2021 apple. All rights reserved.
//

import UIKit
import SwiftUI
import DataManagerHelperRxSwift
import RxSwift
import RxCocoa

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {


         var window: UIWindow?
        var language:String = "EN"
        var deviceID: String?
        let gcmMessageIDKey = "gcm.message_id"
        private let disposeBag = DisposeBag()
    //    var window: UIWindow?
        
        static var shared: AppDelegate {
            return UIApplication.shared.delegate as! AppDelegate
        }
        
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        return true
    }

    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }
    func getAppDelegate() -> AppDelegate {
          return UIApplication.shared.delegate as! AppDelegate
      }

    func initialConfiguration(){

           language = Bundle.main.preferredLocalizations.first?.uppercased() ?? "EN"
           deviceID = UIDevice.current.identifierForVendor!.uuidString
       }
}


struct AppDelegate_Previews: PreviewProvider {
    static var previews: some View {
        /*@START_MENU_TOKEN@*/Text("Hello, World!")/*@END_MENU_TOKEN@*/
    }
}
