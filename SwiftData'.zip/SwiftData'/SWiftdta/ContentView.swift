//
//  ContentView.swift
//  SWiftdta
//
//  Created by Nilesh Vernekar on 03/02/21.
//  Copyright © 2021 apple. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    
     @State var users = ["John","Peter","Jane"]
    
   
    @State  var data: CouponEntityModel?
 
    var body: some View {
//        NavigationView {
        List(data?.couponList ?? []) { item  in
                ListRow(coupondata: item)
            }.onAppear {
                  MyPassesInteractor.shared.myPassesListapiCall()
            }
//        } .navigationBarTitle("My Passes")
    }
}

struct ListRow : View {
    var coupondata:DineCouponListData?
    var body: some View {

     VStack(alignment: .leading) {
        Image("ima").resizable().padding()
        
        HStack (alignment:.firstTextBaseline , spacing: 80 ){
            ZStack(alignment: .leading) {
                    Text("Feature").frame(width: 150, height: 40, alignment: .topLeading)
                    Spacer()
                Text(coupondata?.couponTitle ?? "").frame(width: 150, height: 40, alignment: .bottomLeading)
                }
            ZStack(alignment: .trailing) {
                Button(action: {
                    print("gfg")
                    // What to perform
                }) {
                    Text("view").frame(width: 80, height: 20, alignment: .center)
                        .font(.system(size: 15))          // 3. Change the font type
                        .padding()
                        .border(Color.blue , width: 0.5).cornerRadius(20)
                }
            }
           
           
        }
        
    
      
         }
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
