//
//  Interactor.swift
//  SWiftdta
//
//  Created by Nilesh Vernekar on 03/02/21.
//  Copyright © 2021 apple. All rights reserved.
//

import Foundation


class MyPassesInteractor{
       private let disposeBag = DisposeBag()
      private var dataManager = DataManager()

    
    static let shared = MyPassesInteractor()
    fileprivate func mypassesListHeader() -> [String:Any] {
        var header = [String:Any]()
        header["DEVICE_ID"] = kDeviceID
        header["DEVICE_TYPE"] = "iOS"
        header["Authorization"] = "bearer bf126ab5-2591-49f1-921d-61ff3f918642"
        header["LANGUAGE"] = kLanguage
        return header
    }

     func myPassesListSuccess(data:CouponEntityModel) {
      
       // self.model = data
        //reloadTable()
    }



    //MARK:- faqList Failure
    fileprivate func myPassesListFailure(error: Error) {
        parseError(error: error)
    }

    fileprivate func parseError(error: Error) {
    }


    //MARK:- Request
    fileprivate func mypassesListRequestModel() -> RequestModel {
        let serviceRequestModel = ServiceRequestModel(path: .myPassesList, method: .GET, header: mypassesListHeader(), bodyParameters: nil, getRequestParameters: nil)


        return RequestModel(url: serviceRequestModel.baseURL, path: serviceRequestModel.path.rawValue, method: serviceRequestModel.method.rawValue, header: serviceRequestModel.header, bodyParameters: serviceRequestModel.bodyParameters, getRequestParameters: serviceRequestModel.getRequestParameters)
    }


     func myPassesListapiCall() {
        ServiceManager.shared.serviceCall(apiRequest: mypassesListRequestModel()).subscribe(onSuccess: { [weak self] (model:CouponEntityModel) in
            guard let strongSelf = self else { return }
            strongSelf.myPassesListSuccess(data: model)
            //self?.hideLoader()
        }) { [weak self] error in
            guard let strongSelf = self else { return }
            strongSelf.myPassesListFailure(error: error)
            }.disposed(by: disposeBag)
    }


 

}

