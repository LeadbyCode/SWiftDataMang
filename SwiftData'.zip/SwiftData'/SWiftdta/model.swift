//
//  model.swift
//  SWiftdta
//
//  Created by Nilesh Vernekar on 03/02/21.
//  Copyright © 2021 apple. All rights reserved.
//

import Foundation



class CouponEntityModel: Identifiable,Codable {
    var timeStamp: Int?
    var couponList: [DineCouponListData]?
    var voucherList : [DineCouponListData]?
//    init(timeStamp: Int, couponList: [DineCouponListData]) {
//        self.timeStamp = timeStamp
//        self.couponList = couponList
//    }
}

// MARK: - CouponList
class DineCouponListData: Identifiable,Codable {
    var couponID: Int?
    var couponId: Int?
    var isPassAccepted: Bool?
    var isPassShareable: Bool?
    var couponImagePath,couponListingImg, couponTitle, couponDescription,couponDashboardImg, couponExpiryDate: String?
    var status, termsAndCondition, couponCode: String?
    var startDate, endDate: String?
    var discountValue: Double?
    var expiryType: String?
    var expiryValue: Int?
    var couponTag: String?
    var outletBean: [StoreBeanData]?
    var courseBean: [DineCourseBean]?
    var couponUsageLimit: Int?
    var minOrderAmount: Double?
    var couponUsedCount: Int?
    var voucherId: Int?
    var voucherAvailableFrom : String?
    
    var voucherImagePath, voucherTitle, voucherExpiryDate,voucherTag, voucherCode,voucherDescription,couponCategory : String?
    
    var showQrCode : Bool?
    var validityMessage : String?
    var txnOid : Int?
    var checkinDate: String?
    var redeemableList: [RedeemableList]?
    var purchaseType: [PurchaseType]?
    var accessPassDetails : [AccessPassDetails]?
    var visits: String?
    var monthly, weekly: Int?
    var totalMonthlyCount, totalWeeklyCount : Int?
    var purchase:  Bool?
    var usedBy: String?
    var applicableDays: [String]?
    var applicableTiming: [ApplicableTiming]?
    var redeemAllowed: Bool?
    var merchantId: String?
    var isCheckedIn : Bool?
    var checkedInStore : Int?
    var checkedInTime : String?
    var serverDateAndTime: String?
    var merchantName: String?
    
    var monthlyRemaining : Int?
    var weeklyRemaining : Int?
}

// MARK: - CourseBean
class DineCourseBean: Identifiable,Codable {
    var courseId : Int?
    var courseCode, brandName, latitude, longitude: String?
    var phoneNumber, courseName: String?
    var courseImage: String?
    
//    enum CodingKeys: String, CodingKey {
//        case courseID
//        case courseCode, brandName, latitude, longitude, phoneNumber, courseName, courseImage
//    }
//
//    init(courseID: Int, courseCode: String, brandName: String, latitude: String, longitude: String, phoneNumber: String, courseName: String, courseImage: String) {
//        self.courseID = courseID
//        self.courseCode = courseCode
//        self.brandName = brandName
//        self.latitude = latitude
//        self.longitude = longitude
//        self.phoneNumber = phoneNumber
//        self.courseName = courseName
//        self.courseImage = courseImage
//    }
}

class StoreBeanData: Identifiable,Codable {
       var outletOid: Int?
       var outletId: String?
       var outletName, outletAddress: String?
       var city, country: String?
       var latitude, longitude: String?
       var outletImage: String?
       var phoneNumber: String?
       var bookingAllowed : Bool?
       var isPointRedeemAllowed : Bool?
       var calendarCount: Int?
       var applicableDays: [String]?
       var applicableTiming: [ApplicableTiming]?
       var usedBy: String?
       var isfromView: Bool?
       var outletGetUpdateFlag : Bool?
       var outletDescription : String?
       var termsAndConditions: String?

}


// MARK: - Cuisine
class CuisineListData: Identifiable,Codable {
    var cuisineOID: Int?
    var cuisineName: String?

    enum CodingKeys: String, CodingKey {
        case cuisineOID = "cuisineOid"
        case cuisineName
    }
//
//    init(cuisineOID: Int, cuisineName: String) {
//        self.cuisineOID = cuisineOID
//        self.cuisineName = cuisineName
//    }
}


class RedeemCouponData: Codable {
    let timestamp: Int?
    let couponCode: String?
}


//class DashboardImagesModel: NSObject, Codable {
//    var dashBoardImages : [DashBoardImage]?
//}

//MARK: DashboardImagesModel
class DashboardBannerListModel: NSObject, Codable {
    //var timeStamp : Int?
    var bannerList : [BannerList]?
    var pagecontrol: Int?
}


class BannerList: NSObject, Codable {
    var sequenceNo : Int?
    var bannerName : String?
    var clickThrough : String?
    var startDate : String?
    var endDate : String?
    var linkToDetails : [LinkToDetails]?
    var bannerImage : String?
}


//enum clickThrough: String {
//    case SpecificCoupon = "Specific Coupon"
//    case Outlet = "Outlet"
//    case GolfCourse = "Golf Course"
//    case ViyaWorld = "Viya World"
//    case Outlets = "Outlets"
//
//}
class LinkToDetails: NSObject, Codable {
    var couponList : [CouponListBanner]?
    var outlet : outlet?
    var course : course?
    var viayWorld : ViayWorld?
}

class ViayWorld: NSObject, Codable {
    var tittle : String?
    var imageUrl : String?
    var content : String?
    var videoUrl : String?
    var detailImgPath : String?
}

class CouponListBanner : NSObject, Codable {
    
    var couponId : Int?
    var couponTitle : String?
    var couponDescription : String?
    var couponImagePath : String?
    var couponTag : String?
    var couponCategory : String?
    var couponListingImg : String?
}


class outlet : NSObject, Codable {
    var outletOid : Int?
    var outletName : String?
   
}


class course : NSObject, Codable {
    var courseId : Int?
    var courseName : String?
   
}
class RedeemableList: NSObject, Codable {
    var storeIDS: [Int]?
    var storeCount: Int?
    var courseIDS: [Int]?
    var courseCount: Int?

 
}
class ApplicableTiming: NSObject, Codable {
    var openTime, closeTime: String?
    var storeId: Int?
  
}

// MARK: - PurchaseType
class PurchaseType: NSObject, Codable {
    var type: String?
    var amount: Double?
    var currency: String?
    var isSelected: Bool?
}



// MARK: - PurchaseType
class AccessPassDetails: NSObject, Codable {
    var weekly: Int?
    var quantity: Int?
    var endDate: String?
    var startDate: String?
    var currencyCode: String?
    var motnhly: Int?
    var purchaseType: String?
    var amount: Int?
}
   
