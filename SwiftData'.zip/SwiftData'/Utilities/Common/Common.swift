//
//  Common.swift
//  WASL
//
//  Created by Nilesh Vernekar on 17/10/19.
//  Copyright © 2019 Yashwant Singh. All rights reserved.
//

import Foundation



import Reachability
import UIKit
import Foundation
import libPhoneNumber_iOS
import SystemConfiguration


final class Common {
    
    
    static let Theme_color_light : UIColor = UIColor.init(red: 234.0/255.0, green: 249.0/255.0, blue: 255.0/255.0, alpha: 1.0)
    static let Theme_color_dark : UIColor = UIColor.init(red: 250.0/255.0, green: 145.0/255.0, blue: 0.0/255.0, alpha: 1.0)
    
    
    static let Theme_color_light_notSelected : UIColor = UIColor.init(red: 248.0/255.0, green: 248.0/255.0, blue: 248.0/255.0, alpha: 1.0)
    static let Theme_color_dark_notSelected : UIColor = UIColor.init(red: 211.0/255.0, green: 211.0/255.0, blue: 211.0/255.0, alpha: 1.0)
    static let Theme_textColor_dark_notSelected : UIColor = UIColor.init(red: 60.0/255.0, green: 60.0/255.0, blue: 60.0/255.0, alpha: 1.0)
    
    static let footer_color_lightGray : UIColor = UIColor.init(red: 240.0/255.0, green: 240.0/255.0, blue: 240.0/255.0, alpha: 1.0)
    
    static let AktivLight_14 =  UIFont(name: "AktivGroteskW06-Light", size: 14)
    static let AktivLight_12 =  UIFont(name: "AktivGroteskW06-Light", size: 12)
    
    
    // MARK: - Singleton
    static let shared = Common()
    
    //public static var selectedLocationGlobaleUse:locationCoordinateAndAddress?
    internal static var spinner: UIActivityIndicatorView?
    public static var style: UIActivityIndicatorView.Style = .whiteLarge
    public static var baseBackColor = UIColor(white: 0, alpha: 0.4)
    public static var baseColor = UIColor.orange
    
    
    public static func start(style: UIActivityIndicatorView.Style = style, backColor: UIColor = baseBackColor, baseColor: UIColor = baseColor) {
        if spinner == nil, let window = UIApplication.shared.keyWindow {
            let frame = UIScreen.main.bounds
            spinner = UIActivityIndicatorView(frame: frame)
            spinner!.backgroundColor = backColor
            spinner!.style = style
            spinner?.color = baseColor
            if let data = spinner{
                window.addSubview(data)
                data.startAnimating()
            }
            
            
        }
    }
    
    public static func stop() {
        if spinner != nil {
            DispatchQueue.main.async {
                spinner?.stopAnimating()
                spinner?.removeFromSuperview()
                spinner = nil
            }
        }
    }
    
    
    
    
    
    private let dataManager = DataManager()
    private let disposeBag = DisposeBag()
    
    func SwiftLog(message: String, function: String = #function) {
        #if DEBUG
        SwiftLog(message:"-------------------------------> \(Date()):\(function): \(message)")
        #endif
    }
    
    //    func getFlagImage(countryCode: String) -> UIImage {
    //        var flagName : String!
    //        if countryCode != ""{
    //            flagName = "CountryPicker.bundle/Images/\(countryCode.uppercased())"
    //        }else{
    //            flagName = "CountryPicker.bundle/Images/\(defaultCountry.countryCode.uppercased())"
    //        }
    //
    //        return UIImage.init(named: flagName)!
    //    }
    
    func getFlagImage(countryCode: String) -> UIImage {
        let flagName = "CountryPicker.bundle/Images/\(countryCode.uppercased())"
        return UIImage.init(named: flagName)!
    }
    
    func getCountryList() -> NSArray {
        var countryCodes = NSArray()
        if let path = Bundle.main.path(forResource: "CountryPicker.bundle/Data/countryCodes", ofType: "json") {
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                if let jsonResult = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as? NSArray {
                    countryCodes = jsonResult
                }
            } catch {
                // handle error
                SwiftLog(message: "Unable to fetch OTHER COUNTRY LIST from the resource")
            }
        }
        
        if let path = Bundle.main.path(forResource: "CountryPicker.bundle/Data/frequentlySelectedCountry", ofType: "json") {
            
            do {
                
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                if let jsonResult = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as? NSArray {
                    
                    let descriptor =  NSSortDescriptor(key: "name", ascending: true, selector: #selector(NSString.caseInsensitiveCompare(_:)))
                    return (countryCodes + jsonResult.sortedArray(using: [descriptor]) as NSArray).sortedArray(using: [descriptor]) as NSArray
                }
            } catch {
                print("Unable to fetch OTHER COUNTRY LIST from the resource")
            }
            
        }
        return []
    }
    
    func searchCountry(otherCountryArray: NSArray, getCountryCode: String) -> NSDictionary? {
        var filterArray = NSArray()
        if filterArray.count == 0 {
            filterArray = otherCountryArray.filter { NSPredicate(format: "code = %@", getCountryCode).evaluate(with: $0) } as NSArray
        }
        if filterArray.count > 0 {
            if let getDict = filterArray[0] as? NSDictionary {
                return getDict
            } else {
                return nil
            }
        } else {
            return nil
        }
        
    }
    
    //    func getPhoneCode(countryCode: String) -> String {
    //        var mobileCode:String=""
    //
    //        if let path = Bundle.main.path(forResource: "CountryPicker.bundle/Data/countryCodes", ofType: "json") {
    //            do {
    //                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
    //                if let jsonResult = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as? NSArray {
    //
    //                    // Reciproci.SwiftLog(message:jsonResult)
    //                    for value in jsonResult{
    //                        let new = value as! NSDictionary
    //                        let string = new["code"] as! String
    //                        if string == countryCode{
    //                            mobileCode = new["dial_code"] as! String
    //                        }
    //                    }
    //                }
    //            } catch {
    //                // handle error
    //                //SwiftLog(message: "Unable to fetch OTHER COUNTRY LIST from the resource")
    //            }
    //        }
    //        return mobileCode
    //    }
    
    
    func getPhoneCode(countryCode: String) -> String {
        var mobileCode:String=""
        
        if let path = Bundle.main.path(forResource: "CountryPicker.bundle/Data/countryCodes", ofType: "json") {
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                if let jsonResult = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as? NSArray {
                    
                    // Reciproci.SwiftLog(message:jsonResult)
                    for value in jsonResult{
                        let new = value as! NSDictionary
                        let string = new["code"] as! String
                        if string == countryCode{
                            mobileCode = new["dial_code"] as! String
                        }
                    }
                }
            } catch {
                // handle error
                //SwiftLog(message: "Unable to fetch OTHER COUNTRY LIST from the resource")
            }
        }
        return mobileCode
    }
    
    /*
     Scroll to positon in scrollview
     */
    class func scrollToPositionIn(scrllView: UIScrollView, frame: CGRect, animated: Bool) {
        let scrollPoint: CGPoint = CGPoint(x: 0, y: frame.origin.y)
        scrllView.setContentOffset(scrollPoint, animated: animated)
    }
    
    /**
     *  validating the URL
     */
    class func validateUrl(strUrl: String) -> Bool {
        let urlRegEx: String = "((https|http)://)?((\\w|-)+)(([.]|[/])((\\w|-)+))+"
        let urlTest = NSPredicate(format: "SELF MATCHES %@", argumentArray: [urlRegEx])
        return urlTest.evaluate(with: strUrl)
    }
    
    /**
     *  validating the OTP
     */
    class func specialCharactersCheck(str: String) -> Bool {
        let characterset = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")
        if str.rangeOfCharacter(from: characterset.inverted) != nil {
            //Reciproci.SwiftLog(message:"string contains special characters")
            return true
        }
        return false
    }
    
    //    /**
    //     *  validating the EmailID
    //     */
    //    class func isValidEmail(testStr:String) -> Bool {
    //        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
    //
    //        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
    //        return emailTest.evaluate(with: testStr)
    //    }
    
    
    
    // ---------------------------------------------
    // Showing Custom Error
    // ---------------------------------------------
    class func showCustomErrorWithTitle(title: String, errorMessage: String, presentedOnViewController: UIViewController?) {
        DispatchQueue.main.async{
            var presentedVC = presentedOnViewController
            
            if presentedVC == nil {
                presentedVC = AppDelegate.shared.window?.rootViewController
            }
            
            let alert: UIAlertController = UIAlertController(title: title, message: errorMessage, preferredStyle: UIAlertController.Style.alert)
            
            let defaultAction: UIAlertAction = UIAlertAction(title: NSLocalizedString("OK", comment: ""), style: UIAlertAction.Style.default) { (_) -> Void in
                // Do nothing
            }
            
            alert.addAction(defaultAction)
            presentedVC!.present(alert, animated: true) { () -> Void in
                // Do nothing
            }
        }
    }
    
    
    class func showBottomAlertWithTitle(title: String, errorMessage: String, presentedOnViewController: UIViewController?) {
        DispatchQueue.main.async{
            var presentedVC = presentedOnViewController
            
            if presentedVC == nil {
                presentedVC = AppDelegate.shared.window?.rootViewController
            }
            
            let alert: UIAlertController = UIAlertController(title: title, message: errorMessage, preferredStyle: UIAlertController.Style.actionSheet)
            
            //            let defaultAction: UIAlertAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default) { (_) -> Void in
            //                // Do nothing
            //            }
            
            //            alert.addAction(defaultAction)
            presentedVC!.present(alert, animated: true) { () -> Void in
                // Do nothing
            }
        }
    }
    
    
    // MARK: - MOBILE_NUMBER_VALIDATION
    class func validateMobileNumber(getMobileNumberWithPhoneCode: String, getCountryCode: String) -> Bool {
        let phoneUtil = NBPhoneNumberUtil()
        let myNumber: NBPhoneNumber? = try? phoneUtil.parse(getMobileNumberWithPhoneCode, defaultRegion: getCountryCode)
        //SwiftLog(message:"PHONE CODE === \(getCountryCode)")
        //        SwiftLog(message:"\(getMobileNumberWithPhoneCode) IsValidPhoneNumber ==> \(phoneUtil.isValidNumber(myNumber) ? "YES": "NO")"
        return phoneUtil.isValidNumber(myNumber) ? true: false
    }
    
    // MARK: - EMAILID_VALIDATION
    class func isValidEmail(testStr:String) -> Bool  {
        let stricterFilter: Bool = false
        // Discussion http://blog.logichigh.com/2010/09/02/validating-an-e-mail-address/
        let stricterFilterString: String = "^[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2, 4}$"
        let laxString: String = "^.+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2}[A-Za-z]*$"
        let emailRegex: String = stricterFilter ? stricterFilterString: laxString
        let emailTest = NSPredicate(format: "SELF MATCHES %@", emailRegex)
        return emailTest.evaluate(with: testStr)
    }
    
    /*
     Get Screen Shot for current screen
     */
    class func getCurrentScreenShot() -> UIImage {
        let layer = UIApplication.shared.keyWindow!.layer
        let scale = UIScreen.main.scale
        UIGraphicsBeginImageContextWithOptions(layer.frame.size, false, scale)
        
        layer.render(in: UIGraphicsGetCurrentContext()!)
        let screenshot = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return screenshot!
    }
    
    /*
     Get the screenshot of current screen
     */
    class func getScreenShot(_ view: UIView) -> UIImage {
        let layer = view.layer
        UIGraphicsBeginImageContextWithOptions(layer.frame.size, false, 1.0)
        
        layer.render(in: UIGraphicsGetCurrentContext()!)
        let screenshot = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return screenshot!
    }
    
    class func mergeTwoImages(_ firstImage: UIImage, _ secondImage: UIImage) -> UIImage {
        let size = CGSize(width: 300, height: 300)
        UIGraphicsBeginImageContext(size)
        let areaSize = CGRect(x: 0, y: 0, width: size.width, height: size.height/2)
        let areaSize1 = CGRect(x: 0, y: size.height/2, width: size.width, height: size.height/2)
        firstImage.draw(in: areaSize)
        secondImage.draw(in: areaSize1)
        let newImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        return newImage
    }
    
    //    class func loggedUserData(authToken: String) {
    //        UserDefaults.setObject(authToken as AnyObject, forKey: User.authToken)
    //    }
    //
    //    class func loggedOut() {
    //        UserDefaults.removeObjectForKey(User.authToken)
    //    }
    
    //    class func isUserLoggedIn() -> Bool {
    //        guard UserDefaults.objectForKey(User.authToken) != nil else {
    //            return false
    //        }
    //        return true
    //    }
    
    class func numberWithHypenCheck(string: String) -> Bool {
        let allowedCharacters = "1234567890"
        let allowedCharacterSet = CharacterSet(charactersIn: allowedCharacters)
        let typedCharacterSet = CharacterSet(charactersIn: string)
        let alphabet = allowedCharacterSet.isSuperset(of: typedCharacterSet)
        return alphabet
    }
    
    
    static var defaultAPIHeader: [String: Any] {
        var header: [String: Any] = [String: Any]()
        header["Content-Type"] = "application/json"
        //header["DEVICE_ID"] = kAppDelegate.deviceID
        return header
    }
    
    class func compressImage(_ image: UIImage) -> UIImage {
        var actualHeight: Float = Float(image.size.height)
        var actualWidth: Float = Float(image.size.width)
        let maxHeight: Float = 600.0
        let maxWidth: Float = 800.0
        var imgRatio: Float = actualWidth / actualHeight
        let maxRatio: Float = maxWidth / maxHeight
        let compressionQuality: Float = 0.5
        //50 percent compression
        if actualHeight > maxHeight || actualWidth > maxWidth {
            if imgRatio < maxRatio {
                //adjust width according to maxHeight
                imgRatio = maxHeight / actualHeight
                actualWidth = imgRatio * actualWidth
                actualHeight = maxHeight
            } else if imgRatio > maxRatio {
                //adjust height according to maxWidth
                imgRatio = maxWidth / actualWidth
                actualHeight = imgRatio * actualHeight
                actualWidth = maxWidth
            } else {
                actualHeight = maxHeight
                actualWidth = maxWidth
            }
        }
        let rect = CGRect(x: 0.0, y: 0.0, width: Double(actualWidth), height: Double(actualHeight))
        UIGraphicsBeginImageContext(rect.size)
        image.draw(in: rect)
        let img: UIImage? = UIGraphicsGetImageFromCurrentImageContext()
        //let imageData: Data? = UIImageJPEGRepresentation(img!, CGFloat(compressionQuality))
        let imageData: Data? = img?.jpegData(compressionQuality: CGFloat(compressionQuality))
        
        UIGraphicsEndImageContext()
        
        //let imageSize: Int = imageData!.count
        
        return UIImage.init(data: imageData!)!//UIImage.image(with: imageData!)!
    }
    
    class func showAlertWithAction(viewController: UIViewController, customTitle: String, customMesssage: String, positiveButtonText: String,colourIndex0:UIColor,colourIndex1:UIColor, positiveButtonHandler: @escaping () -> (), negativeButtonText: String, negativeButtonHandler: @escaping () -> ()) {
        let alertController = UIAlertController(title: customTitle, message: customMesssage, preferredStyle: .alert)
        let negativeButton = UIAlertAction(title: negativeButtonText, style: .default, handler: { (alert: UIAlertAction) in negativeButtonHandler() })
        let positiveButton = UIAlertAction(title: positiveButtonText, style: .default, handler: { (alert: UIAlertAction) in positiveButtonHandler() })
        negativeButton.setValue(colourIndex0, forKey: "titleTextColor")
        positiveButton.setValue(colourIndex1, forKey: "titleTextColor")
        
        alertController.addAction(negativeButton)
        alertController.addAction(positiveButton)
        
        DispatchQueue.main.async {
            viewController.present(alertController, animated: true, completion: nil)
        }
    }
    
    
    // MARK: - CHECK_INTERNET_CONNECTIVITY
    class func isConnectedToNetwork() -> Bool {
        
        var zeroAddress = sockaddr_in(sin_len: 0, sin_family: 0, sin_port: 0, sin_addr: in_addr(s_addr: 0), sin_zero: (0, 0, 0, 0, 0, 0, 0, 0))
        zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
        zeroAddress.sin_family = sa_family_t(AF_INET)
        
        let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {zeroSockAddress in
                SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)
            }
        }
        
        var flags: SCNetworkReachabilityFlags = SCNetworkReachabilityFlags(rawValue: 0)
        if SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) == false {
            return false
        }
        
        /* Only Working for WIFI
         let isReachable = flags == .reachable
         let needsConnection = flags == .connectionRequired
         
         return isReachable && !needsConnection
         */
        
        // Working for Cellular and WIFI
        let isReachable = (flags.rawValue & UInt32(kSCNetworkFlagsReachable)) != 0
        let needsConnection = (flags.rawValue & UInt32(kSCNetworkFlagsConnectionRequired)) != 0
        let ret = (isReachable && !needsConnection)
        
        return ret
        
    }
    
    //    class func showSnackBar(stringMessage:String,bottomHeight:CGFloat) {
    //        let message = MDCSnackbarMessage()
    //        message.text = stringMessage
    //        MDCSnackbarManager.messageTextColor = .white
    //        MDCSnackbarManager.snackbarMessageViewBackgroundColor = UIColor.orange
    //        MDCSnackbarManager.show(message)
    //        DispatchQueue.main.async {
    //            MDCSnackbarManager.setBottomOffset(bottomHeight)
    //        }
    //
    //        //MDCSnackbarMessageView.setNeedsUpdateConstraints(<#T##UIView#>)
    //    }
    
    //    class func showActionSnackBar(){
    //        let message = MDCSnackbarMessage()
    //        let action = MDCSnackbarMessageAction()
    //        let actionHandler = {() in
    //            let answerMessage = MDCSnackbarMessage()
    //            answerMessage.text = "Fascinating"
    //            MDCSnackbarManager.show(answerMessage)
    //        }
    //        action.handler = actionHandler
    //        action.title = "OK"
    //        message.action = action
    //        MDCSnackbarManager.show(message)
    //    }
    
    
    class func detectAppleDevice()-> String {
        if UIDevice().userInterfaceIdiom == .phone {
            switch UIScreen.main.nativeBounds.height {
            case 1136: return "iPhone 5 or 5S or 5C"
            case 1334: return "iPhone 6/6S/7/8"
            case 1920, 2208: return "iPhone 6+/6S+/7+/8+"
            case 2436: return "iPhone X, Xs"
            case 2688: return "iPhone Xs Max"
            case 1792: return "iPhone Xr"
            default: return "unknown"
            }
        } else {
            return "unknown"
        }
    }
    
 
    
    // MARK: - CHECK_AVAILIBILITY_OF_KEY_IN_USERDEFAULTS
    func isKeyPresentInUserDefaults(key: String) -> Bool {
        if UserDefaults.standard.object(forKey: key) == nil  {
            return false
        } else {
            return true
        }
    }
    
    //   MARK:- Save Any Data Type in USERDEFAULT
    func saveToUserDefaultsForAny(value: Any, ofKey: String) {
        UserDefaults.standard.set(value, forKey: ofKey)
        UserDefaults.standard.synchronize()
    }
    

 
    
    // MARK: - SAVE_TO_USERDEFAULTS
    func saveToUserDefaults(value: String, ofKey: String) {
        UserDefaults.standard.set(value, forKey: ofKey)
        UserDefaults.standard.synchronize()
    }
    
    // MARK: - RETRIVE_FROM_USERDEFAULTS
    func retriveFromUserDefaults(forKey: String) -> String {
        if isKeyPresentInUserDefaults(key: forKey) {
            return UserDefaults.standard.value(forKey:forKey) as! String
        } else {
            return ""
        }
    }
    
    //   MARK:- Save Any Data Type in USERDEFAULT
    func retriveFromUserDefaultsForAny(ofKey: String) -> Any? {
        if isKeyPresentInUserDefaults(key: ofKey) {
            return UserDefaults.standard.value(forKey:ofKey) as Any
        } else {
            return nil
        }
    }
    
    //MARK:- Alert Helper Method
    func showAlertWithActionAndStyle(viewController: UIViewController, customTitle: String?, customMesssage: String, firstButtonText: String, firstButtonStyle: UIAlertAction.Style ,firstButtonHandler: @escaping () -> (), isSecondButtonRequired: Bool , secondButtonText: String?, secondButtonStyle: UIAlertAction.Style?, secondButtonHandler: @escaping (() -> ())) {
        let alertController = UIAlertController(title: customTitle, message: customMesssage, preferredStyle: .alert)
        let firstButton = UIAlertAction(title: firstButtonText, style: firstButtonStyle, handler: { (alert: UIAlertAction) in firstButtonHandler() })
        alertController.addAction(firstButton)
        if isSecondButtonRequired {
            let secondButton = UIAlertAction(title: secondButtonText, style: secondButtonStyle!, handler: { (alert: UIAlertAction) in secondButtonHandler() })
            alertController.addAction(secondButton)
        }
        DispatchQueue.main.async {
            viewController.present(alertController, animated: true, completion: nil)
        }
    }
    
    func errorMessage(error: Error) -> String {
        let userInfo = error.userInfo
        
        
        let errorModel = ErrorModel(fromDictionary: userInfo)
        if let _ = errorModel.message {
            if let errorDetails = errorModel.errorDetails {
                if errorDetails.count > 0 {
                    if let description = errorDetails[0].descriptionField {
                        return description
                    }
                }
            }
        }
        
        let errorcode = error.code
        switch errorcode {
        case 500 :
            return "Unable to connect Please try again!"
        case 401 :
            return "Loged Out"
        case 400 :
            return "Unable to connect Please try again!"
        default:
            return ""
        }
        
    }
    
    
    func convertDictToJSON(dict: [String:Any]) -> NSString {
        let jsonbody = try! JSONSerialization.data(withJSONObject: dict, options: [])
        return NSString(data: jsonbody, encoding: String.Encoding.utf8.rawValue) ?? ""
    }
    
    

   
    
    //Download image from given URL
    class public func getDataFromUrl(url: URL, completion: @escaping (Data?, URLResponse?, Error?) -> ()) {
        let sessionConfig = URLSessionConfiguration.default
        sessionConfig.timeoutIntervalForRequest = 30.0
        sessionConfig.timeoutIntervalForResource = 30.0
        let session = URLSession(configuration: sessionConfig)
        session.dataTask(with: url) { data, response, error in
            completion(data, response, error)
            }.resume()
    }
    
    
   
    
    // MARK: - GENERATE_BARCODE_FROM_STRING
    func generateBarcode(from string: String) -> UIImage? {
        let data = string.data(using: String.Encoding.ascii)
        
        if let filter = CIFilter(name: "CICode128BarcodeGenerator") {
            filter.setValue(data, forKey: "inputMessage")
            let transform = CGAffineTransform(scaleX: 3, y: 3)
            
            if let output = filter.outputImage?.transformed(by: transform) {
                return UIImage(ciImage: output)
            }
        }
        
        return nil
    }
    
    func generateQRCode(from string: String) -> UIImage? {
        let data = string.data(using: String.Encoding.ascii)
        
        if let filter = CIFilter(name: "CIQRCodeGenerator") {
            filter.setValue(data, forKey: "inputMessage")
            let transform = CGAffineTransform(scaleX: 3, y: 3)
            
            if let output = filter.outputImage?.transformed(by: transform) {
                return UIImage(ciImage: output)
            }
        }
        
        return nil
    }
    func generateBarcodeCode(from string: String) -> UIImage? {
        let data = string.data(using: String.Encoding.ascii)
        
        if let filter = CIFilter(name: "CICode128BarcodeGenerator") {
            filter.setValue(data, forKey: "inputMessage")
            let transform = CGAffineTransform(scaleX: 3, y: 3)
            
            if let output = filter.outputImage?.transformed(by: transform) {
                return UIImage(ciImage: output)
            }
        }
        
        return nil
    }
    
}



