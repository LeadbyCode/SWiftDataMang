//
//  CommonFunctions.swift
//  WASL
//
//  Created by Admin on 24/10/19.
//  Copyright © 2019 Yashwant Singh. All rights reserved.
//

import Foundation
import Reachability
import UIKit
import Foundation
import libPhoneNumber_iOS
import SystemConfiguration

class CommonFunctions: NSObject {
    
    
    static func isObjectInitialized(_ value: AnyObject?) -> Bool {
        guard value != nil else {
            return false
        }
        return true
    }
    
    static let sharedCommon = CommonFunctions()
//    var spinnerActivity = MBProgressHUD()
    /*
     Scroll to positon in scrollview
     */
    class func scrollToPositionIn(scrllView: UIScrollView, frame: CGRect, animated: Bool) {
        let scrollPoint: CGPoint = CGPoint(x: 0, y: frame.origin.y)
        scrllView.setContentOffset(scrollPoint, animated: animated)
    }
    
    /**
     *  validating the URL
     */
    class func validateUrl(strUrl: String) -> Bool {
        let urlRegEx: String = "((https|http)://)?((\\w|-)+)(([.]|[/])((\\w|-)+))+"
        let urlTest = NSPredicate(format: "SELF MATCHES %@", argumentArray: [urlRegEx])
        return urlTest.evaluate(with: strUrl)
    }
    
    /**
     *  validating the OTP
     */
    class func specialCharactersCheck(str: String) -> Bool {
        let characterset = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")
        if str.rangeOfCharacter(from: characterset.inverted) != nil {
            print("string contains special characters")
            return true
        }
        return false
    }
    
    /**
     *  validating the EmailID
     */
    class func isValidEmail(testStr:String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: testStr)
    }
    
    // ---------------------------------------------
    // Showing Custom Error
    // ---------------------------------------------
    class func showCustomErrorWithTitle(title: String, errorMessage: String, presentedOnViewController: UIViewController?) {
        DispatchQueue.main.async{
            var presentedVC = presentedOnViewController
            
//            if presentedVC == nil {
//                presentedVC = AppDelegate.shared.window?.rootViewController
//            }
            
            let alert: UIAlertController = UIAlertController(title: title, message: errorMessage, preferredStyle: UIAlertController.Style.alert)
            
            let defaultAction: UIAlertAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default) { (_) -> Void in
                // Do nothing
            }
            
            alert.addAction(defaultAction)
            presentedVC!.present(alert, animated: true) { () -> Void in
                // Do nothing
            }
        }
    }
    
    /*
     Get Screen Shot for current screen
     */
    class func getCurrentScreenShot() -> UIImage {
        let layer = UIApplication.shared.keyWindow!.layer
        let scale = UIScreen.main.scale
        UIGraphicsBeginImageContextWithOptions(layer.frame.size, false, scale)
        
        layer.render(in: UIGraphicsGetCurrentContext()!)
        let screenshot = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return screenshot!
    }
    
    func getFlagImage(countryCode: String) -> UIImage {
        let flagName = "CountryPicker.bundle/Images/\(countryCode.uppercased())"
        return UIImage.init(named: flagName)!
    }
    
    func getCountryList() -> NSArray {
        
        if let path = Bundle.main.path(forResource: "CountryPicker.bundle/Data/countryCodes", ofType: "json") {
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                if let jsonResult = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as? NSArray {
                    return jsonResult
                }
            } catch {
                // handle error
                //                SwiftLog(message: "Unable to fetch OTHER COUNTRY LIST from the resource")
            }
        }
        return []
    }
    
    func searchCountry(otherCountryArray: NSArray, getCountryCode: String) -> NSDictionary? {
        var filterArray = NSArray()
        if filterArray.count == 0 {
            filterArray = otherCountryArray.filter { NSPredicate(format: "code = %@", getCountryCode).evaluate(with: $0) } as NSArray
        }
        if filterArray.count > 0 {
            if let getDict = filterArray[0] as? NSDictionary {
                return getDict
            } else {
                return nil
            }
        } else {
            return nil
        }
        
    }
    
    func getPhoneCode(countryCode: String) -> String {
        var mobileCode:String=""
        
        if let path = Bundle.main.path(forResource: "CountryPicker.bundle/Data/countryCodes", ofType: "json") {
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                if let jsonResult = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as? NSArray {
                    
                    // Reciproci.SwiftLog(message:jsonResult)
                    for value in jsonResult{
                        let new = value as! NSDictionary
                        let string = new["code"] as! String
                        if string == countryCode{
                            mobileCode = new["dial_code"] as! String
                        }
                    }
                }
            } catch {
                // handle error
                //SwiftLog(message: "Unable to fetch OTHER COUNTRY LIST from the resource")
            }
        }
        return mobileCode
    }

    /*
     Get the screenshot of current screen
     */
    class func getScreenShot(_ view: UIView) -> UIImage {
        let layer = view.layer
        UIGraphicsBeginImageContextWithOptions(layer.frame.size, false, 1.0)
        
        layer.render(in: UIGraphicsGetCurrentContext()!)
        let screenshot = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return screenshot!
    }
    
    class func mergeTwoImages(_ firstImage: UIImage, _ secondImage: UIImage) -> UIImage {
        let size = CGSize(width: 300, height: 300)
        UIGraphicsBeginImageContext(size)
        let areaSize = CGRect(x: 0, y: 0, width: size.width, height: size.height/2)
        let areaSize1 = CGRect(x: 0, y: size.height/2, width: size.width, height: size.height/2)
        firstImage.draw(in: areaSize)
        secondImage.draw(in: areaSize1)
        let newImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        return newImage
    }
    
    class func numberWithHypenCheck(string: String) -> Bool {
        let allowedCharacters = "1234567890-"
        let allowedCharacterSet = CharacterSet(charactersIn: allowedCharacters)
        let typedCharacterSet = CharacterSet(charactersIn: string)
        let alphabet = allowedCharacterSet.isSuperset(of: typedCharacterSet)
        return alphabet
    }
    
    class func showActivityIndicator(presentedOnViewController: UIViewController?) {
        //        let activityIndicator = UIActivityIndicatorView(style: UIActivityIndicatorView.Style.whiteLarge)
        //        activityIndicator.center = CGPoint(x: myBlueSubview.bounds.size.width/2, y: myBlueSubview.bounds.size.height/2)
        //        activityIndicator.color = UIColor.yellow
        //        presentedOnViewController.addSubview(activityIndicator)
    }
    
    class func convertDateFormater(_ date: String) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy HH:mm:ss"
        let date = dateFormatter.date(from: date)
        dateFormatter.dateFormat = "dd/MM/yyyy"
        return  dateFormatter.string(from: date ?? NSDate() as Date)
    }
    
    class func convertDateFormaterInMonthString(_ date: String) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy HH:mm:ss"
        let date = dateFormatter.date(from: date)
        dateFormatter.dateFormat = "dd MMM yyyy"
        return  dateFormatter.string(from: date ?? NSDate() as Date)
    }
    
    class func convertDateFormaterInYearString(_ date: String) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let date = dateFormatter.date(from: date)
        dateFormatter.dateFormat = "EEEE, dd MMM yyyy"
        return  dateFormatter.string(from: date ?? NSDate() as Date)
    }
    
    class func convertDateFormaterInYear(_ date: String) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy HH:mm:ss"
        let date = dateFormatter.date(from: date)
        dateFormatter.dateFormat = "EEEE, dd MMM yyyy"
        return  dateFormatter.string(from: date ?? NSDate() as Date)
    }
    
    class func convertDateFormaterINHours(_ date: String) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy HH:mm:ss"
        let date = dateFormatter.date(from: date)
        dateFormatter.dateFormat = "hh:mm a"
        return  dateFormatter.string(from: date ?? NSDate() as Date)
    }
    
    class func convertDateFormaterInYearNotification(_ date: String) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss.SSS"
        let date = dateFormatter.date(from: date)
        dateFormatter.dateFormat = "dd MMM yyyy"
        return  dateFormatter.string(from: date ?? NSDate() as Date)
    }
    
    class func convertDateFormaterINHoursNotification(_ date: String) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss.SSS"
        let date = dateFormatter.date(from: date)
        dateFormatter.dateFormat = "hh:mm a"
        return  dateFormatter.string(from: date ?? NSDate() as Date)
    }
    
    class func dateType(date:Date) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        dateFormatter.timeStyle = .none
        dateFormatter.dateFormat = "dd/MMM/yyyy"
        let dateString = dateFormatter.string(from: date)
        return dateString
    }
    
    class func convertDateFormaterToMonth(_ date: String) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MMM-yyyy"
        let date = dateFormatter.date(from: date)
        dateFormatter.dateFormat = "d MMM"
        return  dateFormatter.string(from: date ?? NSDate() as Date)
    }
    
    
    class func convertSignUpDateFormaterInYearNotification(_ date: String) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MMM/yyyy"
        let date = dateFormatter.date(from: date)
        dateFormatter.dateFormat = "dd/MM/yyyy"
        if let dateStr = date  {
            return dateFormatter.string(from: dateStr)
        }
        return ""
    }
    
    func abc(date: String) -> String {
        let dateFomatter = DateFormatter()
        dateFomatter.dateFormat = "dd-MM-yyyy"
        if let dates = dateFomatter.date(from: date) {
            dateFomatter.dateFormat = "dd MMM"
            return dateFomatter.string(from: dates)
        }
        return ""
    }
    
    class func stringToDateConvert(_ date: String) -> Date {
        
        if date.isEmpty==false || date == "00-00-0000" {
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
            dateFormatter.locale = Locale(identifier: "en_US_POSIX") // set locale to reliable US_POSIX
            
            let dateValue = dateFormatter.date(from:date)
            return dateValue ?? Date()
        }
        return Date()
    }
    
    class func timeAgoSinceDate(_ date:Date ) -> String? {
        let calendar = NSCalendar.current
        let unitFlags: Set<Calendar.Component> = [.minute, .hour, .day, .weekOfYear, .month, .year, .second]
        let now = Date()
        let earliest = now < date ? now : date
        let latest = (earliest == now) ? date : now
        let components = calendar.dateComponents(unitFlags, from: earliest,  to: latest)
        let dateFormatterGet = DateFormatter()
        dateFormatterGet.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let datetype = DateFormatter()
        datetype.dateFormat = "dd-MM-yyyy "
        
        if (components.minute! >= 1) {
            return "\(components.minute!) min"
        } else {
            return "min"
        }
    }
    
    class func base64ToImage(bsae64Str: String) -> UIImage? {
        
        if let decodedData = Data(base64Encoded: bsae64Str, options: .ignoreUnknownCharacters) {
            let image = UIImage(data: decodedData)
            return image
        }
        return UIImage()
    }
    
    
    // MARK: - User Defaults
    /**
     sets/adds object to NSUserDefaults
     
     - parameter aObject: object to be stored
     - parameter defaultName: key for object
     */
    class func setObject(_ value: AnyObject?, forKey defaultName: String) {
        UserDefaults.standard.set(value, forKey: defaultName)
        UserDefaults.standard.synchronize()
    }
    
    /**
     gives stored object in NSUserDefaults for a key
     
     - parameter defaultName: key for object
     
     - returns: stored object for key
     */
    class func objectForKey(_ defaultName: String) -> AnyObject? {
        return UserDefaults.standard.object(forKey: defaultName) as AnyObject?
    }
    
    /**
     removes object from NSUserDefault stored for a given key
     
     - parameter defaultName: key for object
     */
    class func removeObjectForKey(_ defaultName: String) {
        UserDefaults.standard.removeObject(forKey: defaultName)
        UserDefaults.standard.synchronize()
    }
    
 
    
 
    
  
    
  
    
    class func convertdecimalFormater(number: Double) -> String
    {
        let myNumber = NSNumber(value: number)
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = .decimal
        let formattedNumber = numberFormatter.string(from: myNumber)
        return formattedNumber ?? ""
    }
    
    // MARK: - CHECK_INTERNET_CONNECTIVITY
    class func isConnectedToNetwork() -> Bool {

        var zeroAddress = sockaddr_in(sin_len: 0, sin_family: 0, sin_port: 0, sin_addr: in_addr(s_addr: 0), sin_zero: (0, 0, 0, 0, 0, 0, 0, 0))
        zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
        zeroAddress.sin_family = sa_family_t(AF_INET)

        let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {zeroSockAddress in
                SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)
            }
        }

        var flags: SCNetworkReachabilityFlags = SCNetworkReachabilityFlags(rawValue: 0)
        if SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) == false {
            return false
        }

        /* Only Working for WIFI
         let isReachable = flags == .reachable
         let needsConnection = flags == .connectionRequired

         return isReachable && !needsConnection
         */

        // Working for Cellular and WIFI
        let isReachable = (flags.rawValue & UInt32(kSCNetworkFlagsReachable)) != 0
        let needsConnection = (flags.rawValue & UInt32(kSCNetworkFlagsConnectionRequired)) != 0
        let ret = (isReachable && !needsConnection)

        return ret

//        return true

    }
    
    // MARK: - MOBILE_NUMBER_VALIDATION
    class func validateMobileNumber(getMobileNumberWithPhoneCode: String, getCountryCode: String) -> Bool {
        let phoneUtil = NBPhoneNumberUtil()
        let myNumber: NBPhoneNumber? = try? phoneUtil.parse(getMobileNumberWithPhoneCode, defaultRegion: getCountryCode)
        //SwiftLog(message:"PHONE CODE === \(getCountryCode)")
        //        SwiftLog(message:"\(getMobileNumberWithPhoneCode) IsValidPhoneNumber ==> \(phoneUtil.isValidNumber(myNumber) ? "YES": "NO")"
        return phoneUtil.isValidNumber(myNumber) ? true: false
    }
    
    class func detectAppleDevice()-> String {
        if UIDevice().userInterfaceIdiom == .phone {
            switch UIScreen.main.nativeBounds.height {
            case 1136: return "iPhone 5 or 5S or 5C"
            case 1334: return "iPhone 6/6S/7/8"
            case 1920, 2208: return "iPhone 6+/6S+/7+/8+"
            case 2436: return "iPhone X, Xs"
            case 2688: return "iPhone Xs Max"
            case 1792: return "iPhone Xr"
            default: return "unknown"
            }
        } else {
            return "unknown"
        }
    }
    
    // MARK: - SAVE_TO_USERDEFAULTS
    func saveToUserDefaults(value: String, ofKey: String) {
        UserDefaults.standard.set(value, forKey: ofKey)
        UserDefaults.standard.synchronize()
    }
    
    // MARK: - GET_DEVICE_ID
    func getDeviceId () -> String {
        return (UIDevice.current.identifierForVendor?.uuidString)!
    }
    
    // MARK: - RETRIVE_FROM_USERDEFAULTS
    func retriveFromUserDefaults(forKey: String) -> String {
        if isKeyPresentInUserDefaults(key: forKey) {
            return UserDefaults.standard.value(forKey:forKey) as! String
        } else {
            return ""
        }
    }
    
    func isObjectInitialized(_ value: AnyObject?) -> Bool {
        guard value != nil else {
            return false
        }
        return true
    }
    // MARK: - Error Message
//    func errorMessage(error: Error) -> String {
//        let userInfo = error.userInfo
//
//        let errorModel = ErrorModel.init()
//        if let _ = errorModel.message {
//            if let errorDetails = errorModel.errorDetails {
//                if errorDetails.count > 0 {
//                    return errorDetails[0].descriptionField ?? error.localizedDescription
//                } else {
//                    return error.localizedDescription
//                }
//            }else {
//                return error.localizedDescription
//            }
//        }else {
//            return error.localizedDescription
//        }
//
//    }
 
    // MARK: - Error Message
//    func errorMessage(error: Error) -> String {
//
//        let userInfo = error.userInfo
//
//        let errorModel = ErrorModel(fromDictionary: userInfo)
//        if let eroor = errorModel.message {
//            if let errorDetails = errorModel.errorDetails {
//                if errorDetails.count > 0 {
//                    return errorDetails[0].descriptionField ?? error.localizedDescription
//                } else {
//                    return error.localizedDescription
//                }
//            } else {
//                return error.localizedDescription
//            }
//        } else {
//            return error.localizedDescription
//        }
//
//    }
 
    func errorMessage(error: Error) -> String {
        let userInfo = error.userInfo
        
        
        let errorModel = ErrorModel(fromDictionary: userInfo)
        if let _ = errorModel.message {
            if let errorDetails = errorModel.errorDetails {
                if errorDetails.count > 0 {
                    if let description = errorDetails[0].descriptionField {
                        return description
                    }
                }
            }
        }
        
        let errorcode = error.code
        switch errorcode {
        case 500 :
            return "Unable to connect Please try again."
        case 401 :
            return "Loged Out"
        case 400 :
            return "Unable to connect Please try again."
        default:
            return "Unable to connect Please try again."
        }
        
    }
    
    
    
    // MARK: - CHECK_AVAILIBILITY_OF_KEY_IN_USERDEFAULTS
    func isKeyPresentInUserDefaults(key: String) -> Bool {
        if UserDefaults.standard.object(forKey: key) == nil  {
            return false
        } else {
            return true
        }
        
    }
    
    // MARK: - CUSTOM_LOADER
//    func addLoadingView (parentVC: UIViewController, function: String = #function) {
//
//        spinnerActivity = MBProgressHUD.showAdded(to: parentVC.view, animated: true)
//        spinnerActivity.animationType = MBProgressHUDAnimation.zoom
//        spinnerActivity.mode = MBProgressHUDMode.indeterminate
//        spinnerActivity.bezelView.color = UIColor(red: 247.0/255.0, green: 222.0/255.0, blue: 117.0/255.0, alpha: 1.0)
//        spinnerActivity.bezelView.alpha = 0.7
//        spinnerActivity.bezelView.style = .blur
//        parentVC.navigationController?.navigationBar.isUserInteractionEnabled = false
//        parentVC.navigationController?.view.isUserInteractionEnabled = false
//    }
    
//    func removeLoadingView (parentVC: UIViewController, function: String = #function) {
//
//        spinnerActivity.hide(animated: true)
//        parentVC.navigationController?.navigationBar.isUserInteractionEnabled = true
//        parentVC.navigationController?.view.isUserInteractionEnabled = true
//    }
    

    func showAlertWithActionAndStyle(viewController: UIViewController, customTitle: String?, customMesssage: String, firstButtonText: String, firstButtonStyle: UIAlertAction.Style ,firstButtonHandler: @escaping () -> (), isSecondButtonRequired: Bool , secondButtonText: String?, secondButtonStyle: UIAlertAction.Style?, secondButtonHandler: @escaping (() -> ())) {
        let alertController = UIAlertController(title: customTitle, message: customMesssage, preferredStyle: .alert)
        let firstButton = UIAlertAction(title: firstButtonText, style: firstButtonStyle, handler: { (alert: UIAlertAction) in firstButtonHandler() })
        alertController.addAction(firstButton)
        if isSecondButtonRequired {
            let secondButton = UIAlertAction(title: secondButtonText, style: secondButtonStyle!, handler: { (alert: UIAlertAction) in secondButtonHandler() })
            alertController.addAction(secondButton)
        }
        DispatchQueue.main.async {
            viewController.present(alertController, animated: true, completion: nil)
        }
    }
    
    
    func isBarcodeValid(_ checkBarcode: String) -> Bool {
        let validBarcodeRegex: String = "^[a-zA-Z0-9]*$"
        let validBarcodeTest = NSPredicate(format: "SELF MATCHES %@", validBarcodeRegex)
        return validBarcodeTest.evaluate(with: checkBarcode)
    }
    
    fileprivate func downloaded(from url: URL, completionHandler:@escaping (UIImage) -> Void) {
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200, let mimeType = response?.mimeType, mimeType.hasPrefix("image"), let data = data, error == nil, let image = UIImage(data: data) else { return }
            completionHandler(image)
            }.resume()
    }
    
    public func downloaded(from link: String, completionHandler:@escaping (UIImage) -> Void) {  // for swift 4.2 syntax just use ===> mode: UIView.ContentMode
        guard let url = URL(string: link) else { return }
        downloaded(from: url) { image in
            completionHandler(image)
        }
    }
    
    //    class func tabBarSetup(isHidden: Bool) {
    //            TabbarViewController.tabbarViewController?.tabBar.isHidden = isHidden
    //    }
    
    func convertDictToJSON(dict: [String:Any]) -> NSString {
        let jsonbody = try! JSONSerialization.data(withJSONObject: dict, options: [])
        return NSString(data: jsonbody, encoding: String.Encoding.utf8.rawValue) ?? ""
    }
    
    class func timeFormator(  time: String) -> String {
        var timesplits = time.components(separatedBy: ":")
        let hrs = timesplits[0]
        let min = timesplits[1]
        if (hrs == "00") {
            return min + " mins"
        } else
        {
            return hrs + ":" + min + " hrs"
        }
    }
    
  
}
extension Notification.Name {
    static let saveTransactionType = Notification.Name(rawValue: "TransactionType")
}
