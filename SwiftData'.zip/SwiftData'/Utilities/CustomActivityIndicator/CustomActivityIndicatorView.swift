//
//  CustomActivityIndicatorView.swift
//  ClubApparel_Cust
//
//  Created by Dhritiman Saha on 28/06/17.
//  Copyright © 2017 Dhritiman Saha. All rights reserved.
//

import UIKit

class CustomActivityIndicatorView: UIView {

    @IBOutlet var mContentView: UIView!
    @IBOutlet weak var mActivityBackMainView: UIVisualEffectView!
    @IBOutlet weak var mActivityIndicatorOutlet: UIActivityIndicatorView!
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    var view:UIView!
    
    override init(frame:CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init(coder aCoder: NSCoder) {
        super.init(coder: aCoder)!
        commonInit()
    }
    
    func commonInit() {
        Bundle.main.loadNibNamed("CustomActivityView", owner: self, options: nil)
        addSubview(mContentView)
        mContentView.frame = UIScreen.main.bounds
        mActivityIndicatorOutlet.startAnimating()
    }
    
    public func removeIndicatorFromSuperview() {
        mActivityIndicatorOutlet.stopAnimating()
        mContentView.removeFromSuperview()
    }
    
}
