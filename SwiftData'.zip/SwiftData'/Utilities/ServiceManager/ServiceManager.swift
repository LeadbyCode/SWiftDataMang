//
//  ServiceManager.swift
//  WASL
//
//  Created by Nilesh Vernekar on 06/12/19.
//  Copyright © 2019 Yashwant Singh. All rights reserved.
//

import Foundation
import DataManagerHelperRxSwift
import RxSwift
import RxCocoa

class ServiceManager {
    
    static let shared = ServiceManager()
    
    private let dataManager = DataManager()
    private let disposeBag  = DisposeBag()
    
    private init() {}
    
    public func serviceCall<T: Decodable>(apiRequest: RequestModel) -> Single<T> {
        var apiRequest = apiRequest
        return Single<T>.create { [weak self] single in
            let disposable = Disposables.create()
            guard let strongSelf = self else { return disposable }
            
            strongSelf.service(apiRequest: apiRequest).subscribe(onSuccess: { (model: T) in
                
                single(.success(model))
                
            }) { (error: Error) in
                
                strongSelf.responseCode(error: error).subscribe(onSuccess: { [weak self] (model: AuthFailureModel) in
                    
                    guard let strongSelf = self else { return }
                    
                    strongSelf.service(apiRequest: apiRequest).subscribe(onSuccess: { (model: T) in
                        single(.success(model))
                    }, onError: { (error: Error) in
                        single(.error(error))
                    }).disposed(by: strongSelf.disposeBag)
                    
                    }, onError: { error in
                        
                        single(.error(error))
                        
                }).disposed(by: strongSelf.disposeBag)
                }.disposed(by: strongSelf.disposeBag)
            
            
            
            return disposable
        }
    }
    
    fileprivate func service<T: Decodable>(apiRequest: RequestModel) -> Single<T> {
        return dataManager.serviceCall(apiRequest: apiRequest)
    }
    
    fileprivate func responseCode<T: Decodable>(error: Error) -> Single<T> {
        return Single<T>.create { [weak self] single in
            let disposable = Disposables.create()
            guard let strongSelf = self else { return disposable }
            
            return disposable
        }
    }
    
    
  
}
