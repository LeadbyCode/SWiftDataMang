//
//  AuthFailureModel.swift
//  WASL
//
//  Created by Nilesh Vernekar on 06/12/19.
//  Copyright © 2019 Yashwant Singh. All rights reserved.
//

import Foundation


class AuthFailureModel: NSObject, Decodable {
    
    var access_token : String?
    var expires_in : Int?
    var refresh_token : String?
    var scope : String?
    var token_type : String?
    
}
