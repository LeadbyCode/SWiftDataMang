//
//  ConstantURL.swift
//  WASL
//
//  Created by Admin on 24/10/19.
//  Copyright © 2019 Yashwant Singh. All rights reserved.
//

import Foundation



let environment : NetworkEnvironment = .Uat                 //=====UAT
enum NetworkEnvironment {
    case Sit
    case Uat
    case Production
    case PreProd
}

let SIT = "http://182.72.208.175:8080"

 let UAT = "https://wasl-admin-service-uat.reciproci.com"
let PREPROD = "https://wasl-api-preprod.reciproci.com"
let PRODUCTION = "https://caprod.reciproci.com/"

public enum RequestType: String {
    case GET, POST, PUT, DELETE, PATCH
}

public enum RelativeURL: String {

    case myPassesList = "/api/ns/coupon/v2/accessCouponList"
    
  
}

struct Welcome {
    static let authToken = "authToken"
    static let feedbackUrl = "feedbackUrl"
    static let flowId = "flowId"
    static let footerColor = "footerColor"
    static let footerImage = "footerImage"
    static let footerText = "footerText"
    static let headerColor = "headerColor"
    static let kioskId = "kioskId"
    static let latitude = "latitude"
    static let logoPath = "logoPath"
    static let longitude = "longitude"
    static let status = "status"
    static let timestamp = "timestamp"
    static let message = "message"
    static let flowUrl = "flowUrl"
    static let idleTimeOut = "idleTimeOut"
    static let finalPageDuration = "finalPageDuration"
    static let brandLogo = "brandLogo"
}

struct currentLocation {
    static let longitude = "longitude"
    static let latitude = "latitude"
}
