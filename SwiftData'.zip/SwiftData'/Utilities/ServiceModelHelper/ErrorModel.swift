//
//  ErrorModel.swift
//  SWiftdta
//
//  Created by Nilesh Vernekar on 03/02/21.
//  Copyright © 2021 apple. All rights reserved.
//

import Foundation
class ErrorModel: NSObject {
    
    var errorDetails : [ErrorDetail]!
    var errorType : String?
    var message : String?
    var timestamp : Int?
    var Status : String?
    
    
    init(fromDictionary dictionary: [String:Any]){
        errorDetails = [ErrorDetail]()
        if let errorDetailsArray = dictionary["errorDetails"] as? [[String:Any]]{
            for dic in errorDetailsArray{
                let value = ErrorDetail(fromDictionary: dic)
                errorDetails.append(value)
            }
        }
        errorType = dictionary["errorType"] as? String
        message = dictionary["message"] as? String
        timestamp = dictionary["timestamp"] as? Int
        Status = dictionary["Status"] as? String
    }
    
}

class ErrorDetail{
    
    var descriptionField : String?
    var field : String?
    var Status : String?
    
    init(fromDictionary dictionary: [String:Any]){
        descriptionField = dictionary["description"] as? String
        field = dictionary["field"] as? String
        Status = dictionary["Status"] as? String
    }
    
}
