//
//  GlobalStatusCode.swift
//  SWiftdta
//
//  Created by Nilesh Vernekar on 03/02/21.
//  Copyright © 2021 apple. All rights reserved.
//

import Foundation

struct Verification:Codable {
    let timestamp:Int?
    let message:String?
    let referenceId:String?
}

struct RegistrationDone:Codable {
    let message:String?
    let timestamp:CLong?
    let updateStatusCode:Int?
}

struct TextFieldValidation {
    static let mobileMaxLength = 10
}

struct OTPTimerSeconds {
    static let seconds = 180
}



struct User {
    static let authToken = "authToken"
    static let referenceId = "referenceId"
    static let timestamp = "timestamp"
    static let deviceToken = "deviceToken"
    static let profileImagePath = "profileImagePath"
    
    static let access_token = "access_token"
    static let expires_in = "expires_in"
    static let refresh_token = "refresh_token"
    static let scope = "scope"
    static let token_type = "token_type"
    static let username = "userName"
    static let password = "password"
    
    
    static let IS_LOGGEDIN = "IS_LOGGEDIN"
    static let IS_LOGGEDOUT = "IS_LOGGEDOUT"
}

struct errorMessages {
    static let vaildFirstName = NSLocalizedString("Enter vaild First Name.", comment: "")
    static let vaildLastName = NSLocalizedString("Enter vaild Last Name.", comment: "")
    static let vaildEmailID = NSLocalizedString("Please enter valid email.", comment: "")
    static let emptyDOB = NSLocalizedString("Please enter date of birth.", comment: "")
    static let emptyprofession = NSLocalizedString("Please enter profession.", comment: "")
    static let emptysourceOfIncome = NSLocalizedString("Please enter profession.", comment: "")
    static let emptyphoneNumber = NSLocalizedString("Please enter Phone number.", comment: "")
    static let emptyaddress = NSLocalizedString("Please enter address.", comment: "")
    static let emptyImage = NSLocalizedString("Please select Image.", comment: "")
    static let emptyfrontImage = NSLocalizedString("Please select front Image.", comment: "")
    static let emptybackIDImage = NSLocalizedString("Please select backID Image.", comment: "")
    static let emiratesType = NSLocalizedString("Please enter emirates Type.", comment: "")
    static let emiratesID = NSLocalizedString("Please enter emirates ID.", comment: "")
    static let emptyissuesDate = NSLocalizedString("Please enter issues Date.", comment: "")
    static let emptyexpiryDate = NSLocalizedString("Please enter expiry Date.", comment: "")
    static let vaildPassword = NSLocalizedString("Enter vaild 4 digit password.", comment: "")
    static let passwordNotEqual = NSLocalizedString("New and Confirm password doesn’t match, please re-enter.", comment: "")
    static let credentialsNotMatching = NSLocalizedString("Entered credentials doesn't match, please re-enter.", comment: "")
    static let passwordChangeSuccessfull = NSLocalizedString("Password successfully Changed.", comment: "")
    static let validMobile = NSLocalizedString("please enter valid mobile number.", comment: "")
}

struct popupMessage {
    static let appTitle = "VIYA"
    static let logoutPopUp = NSLocalizedString("Do you want to logout", comment: "")
}

struct GlobalStatusCode {
    static let sucess = 200
    static let failure = 400
    static let authFailure = 401
    static let someError = 404
    static let someBadError = 500
}

struct RegistrationStatusCode {
    static let AlreadyRegisteredLogin = "S002"
    static let MobileNumberAndEmiratesIdMissMatch = "S004"
    static let AlreadyRegisteredSetPassword = "S003"
    static let ApprovalPending = "S005"
}
