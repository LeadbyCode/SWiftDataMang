//
//  HederModel.swift
//  WASL
//
//  Created by Admin on 24/10/19.
//  Copyright © 2019 Yashwant Singh. All rights reserved.
//

import Foundation

let kLanguage = AppDelegate.shared.language
let kDeviceID = AppDelegate.shared.deviceID
let kCountryCode = "IN"
struct HederModel {
    static let countrycode = "IN"
    static let cityname = "Noida"
    static let devicetype = "iOS"
}
