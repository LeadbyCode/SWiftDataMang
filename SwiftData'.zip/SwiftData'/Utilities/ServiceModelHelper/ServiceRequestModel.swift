//
//  ServiceRequestModel.swift
//  WASL
//
//  Created by Admin on 24/10/19.
//  Copyright © 2019 Yashwant Singh. All rights reserved.
//

import Foundation

protocol ServiceModel {
    var method: RequestType { get }
    var path: RelativeURL { get }
    var getRequestParameters: [String : String]? { get }
    var bodyParameters: [String : Any]? { get }
    var header: [String : Any]? { get }
}

class ServiceRequestModel: ServiceModel {
    
    
    private var environmentBaseURL : String {
        switch environment {
        case .Sit: return SIT
        case .Uat: return UAT
        case .PreProd: return PREPROD
        case .Production: return PRODUCTION
        }
    }
    
    var baseURL: URL {
        guard let url = URL(string: environmentBaseURL) else { fatalError("baseURL could not be configured.")}
        return url
    }
    
    var mockURL = URL(string: "https://22745baf-3d57-49d7-8adc-87e6f67e25ed.mock.pstmn.io")
    
    var method: RequestType
    var path: RelativeURL
    var getRequestParameters: [String : String]?
    var bodyParameters: [String : Any]?
    var header: [String : Any]?
    
    public init(path: RelativeURL, method: RequestType, header: [String:Any]?, bodyParameters: [String:Any]?, getRequestParameters: [String:String]?) {
        self.bodyParameters = bodyParameters
        self.method = method
        self.path = path
        self.header = header
        self.getRequestParameters = getRequestParameters
    }
    
    deinit {
        debugPrint(String(describing: self), "De-Init")
    }
}
